try:
    import Lib
except:
    from . import Lib
import pandas as pd
from datetime import date,timedelta,datetime
import logging
import json

import os
import calendar
from dateutil import parser
import re
from difflib import SequenceMatcher
from db_utils import DB
from dateutil.parser import parse
from dateutil.relativedelta import *
from babel.numbers import format_decimal
import copy

try:
    from ace_logger import Logging
    
    logging = Logging()
except:
    import logging 
    logger=logging.getLogger() 
    logger.setLevel(logging.DEBUG) 
 
db_config = {
    'host': os.environ['HOST_IP'],
    'user': os.environ['LOCAL_DB_USER'],
    'password': os.environ['LOCAL_DB_PASSWORD'],
    'port': os.environ['LOCAL_DB_PORT']
}

__methods__ = [] # self is a BusinessRules Object
register_method = Lib.register_method(__methods__)

@register_method
def evaluate_static(self, function, parameters):
    if function == 'Assign':
        return self.doAssign(parameters)
    if function == 'AssignQ':
        return self.doAssignQ(parameters)
    if function == 'AssignTable':
        return self.doAssignTable(parameters)
    if function == 'CompareKeyValue':
        return self.doCompareKeyValue(parameters)
    if function == 'GetLength':
        return self.doGetLength(parameters)
    if function == 'GetRange':
        return self.doGetRange(parameters)
    if function == 'Selectcase':
        return self.doSelectcase(parameters)
    if function == 'Select':
        return self.doSelect(parameters)
    if function == 'Transform':
        return self.doTransform(parameters)
    if function == 'Count':
        return self.doCount(parameters)
    if function == 'Contains':
        return self.doContains(parameters)
    if function == 'ContainsMaster':
        return self.doContainsMaster(parameters)
    if function == 'case_gen':
        return self.docase_gen(parameters)
    if function == 'authority':
        return self.doAuthority(parameters)
    if function == 'due_date_generate':
        return self.Dodue_date_generate(parameters)
    if function == 'Bank_due_date_generate':
        return self.BankDodue_date_generate(parameters)
    if function == 'Get_holidays_fromdatabase':
        return self.get_holidays_fromdatabase(parameters)
    if function == 'sat_and_sun_holidays':
        return self.doSat_and_sun_holidays(parameters)
    if function == 'ContainsAccount_GHO':
        return self.doContainsAccount_GHO(parameters)
    if function == 'Contains_UCIC':
        return self.doContains_UCIC(parameters)
    if function == 'FindDuplicates':
        return self.doFindDuplicates(parameters)
    if function == 'FindDuplicatesTables':
        return self.doFindDuplicatesTables(parameters)
    if function == 'FindTotal':
        return self.doFindTotal(parameters)
    if function == 'DateParsing':
        return self.doDateParsing(parameters)
    if function == 'DateParsingMarch':
        return self.doDateParsingMarch(parameters)
    if function == 'Replace':
        return self.doReplace(parameters)
    if function == 'Split':
        return self.doSplit(parameters)
    if function == 'Return':
        return self.doReturn(parameters)
    if function == 'RegexColumns':
        return self.doRegexColumns(parameters)
    if function == 'alnum_and_contains':
        return self.alnum_and_contains(parameters)
    if function == 'AlphaNumCheck':
        return self.doAlphaNumCheck(parameters)
    if function == 'FindDuplicateID':
        return self.doFindDuplicateID(parameters)
    if function == 'DateTransform':
        return self.doDateTransform(parameters)
    if function == 'PartialMatch':
        return self.doPartialMatch(parameters)
    if function == 'FileManagerUpdate':
        return self.doFileManagerUpdate(parameters)
    if function == 'MultiplyAmountFields':
        return self.doMultiplyAmountFields(parameters)
    if function == 'UnitsCalculation':
        return self.doUnitsCalculation(parameters)
    if function == 'UnitsCalculationColumn':
        return self.doUnitsCalculationColumn(parameters)
    if function == 'Round':
        return self.doRound(parameters)
    if function == 'Contains_string':
        return self.doContains_string(parameters)
    if function == 'Alnum_num_alpha':
        return self.doAlnum_num_alpha(parameters)
    if function == 'Regex':
        return self.doRegex(parameters)
    if function == 'Zfill':
        return self.doZfill(parameters)
    if function == 'MultiplyAmountFields':
        return self.doMultiplyAmountFields(parameters)
    if function == 'LTDandTDScalc':
        return self.doLTDandTDScalc(parameters)
    if function == 'AmountCompare':
        return self.AmountCompare(parameters)
    if function == 'duplicatecase':
        return self.duplicatecase(parameters)
    if function == 'SelectCustom':
        return self.doSelectCustom(parameters)
    if function == 'ProduceData':
        return self.doProduceData(parameters)
    if function == 'AppendDB':
        return self.doAppendDB(parameters)
    if function == 'PartialCompare':
        return self.doPartialCompare(parameters)
    if function == 'GetColumnValue':
        return self.doGetColumnValue(parameters)
    if function == 'Delete':
        return self.doDelete(parameters)
    if function == 'DateCheck':
        return self.doDateCheck(parameters)
    if function == 'TablesDeloitte':
        return self.doTablesDeloitte(parameters)
    if function == 'AuditUpdate':
        return self.doAuditUpdate(parameters)
    if function == 'DateParser':
        return self.doDateParser(parameters)
    if function == 'ClientIDselect':
        return self.doClientIDselect(parameters)
    if function == 'VendorIDselect':
        return self.doVendorIDselect(parameters)
    if function == 'AmountSyntax':
        return self.doAmountSyntax(parameters)
    if function == 'SplitConcate':
        return self.doSplitConcate(parameters)
    if function == 'getusername':
        return self.dogetusername(parameters)
    if function == 'GetDateTime':
        return self.doGetDateTime(parameters)
    if function == 'ColSum':
        return self.doColSum(parameters)
    if function == 'TableAppendDB':
        return self.doTableAppendDB(parameters)       
    if function == 'CompareTableColumn':
        return self.doCompareTableColumn(parameters)  
    if function == 'TableErrorMessages':
        return self.doTableErrorMessages(parameters)
    if function == 'CompareTableColumntrue':
        return self.doCompareTableColumntrue(parameters)
    if function == 'tablerowcompare':
        return self.dotablerowcompare(parameters)    
    if function == 'hsntablecompare':
        return self.dohsntablecompare(parameters)    


@register_method
def dohsntablecompare(self,parameters):
    """ 
      'parameters':{
        'Table:{'source':'input_config','table':'ocr','column':'Table'},
        'table_column':'comments'
        'compare_value':''  
    }

    'returns':
        ace table with comments added
    # """
    
    logging.info(f"parameters got for TableAppendDB are {parameters}")

    ace_table = self.get_param_value(parameters['Table'])
    append_value = self.get_param_value(parameters['append_value'])
    table_column = parameters['table_column']
    comment_column = parameters['comment_column']
    compare_value = parameters['compare_value']
    original_ace_table = copy.deepcopy(ace_table)
    master_table = 'hsn_master'
    master_column = 'hsn_code'
    bool_value = True
    df = pd.DataFrame(self.data_source[master_table])
    master_col_List = list(df[master_column].astype(str))
    try:  
        if not ace_table:
            ace_table = []
            table_data = {}
            return ace_table
        else:
            ace_table = json.loads(ace_table)
            table_data = ace_table[0]
            if "rowData" not in table_data:
                logging.debug(f"RowData is empty for ace_table")
            else:
                rows = table_data['rowData']
                if not rows:
                    logging.debug(f"rows is empty for ace_table")
                else:
                    for i,row in enumerate(rows):
                        hsn_range = (str(row[table_column])[0: ])
                        if hsn_range in master_col_List:
                            bool_value = False
                        else:
                            bool_value = True
                        table_col_length = len(row[table_column])
                        if bool_value or (table_col_length < compare_value):
                            if row[comment_column]!= '':
                                row[comment_column]=row[comment_column] + ", "+ append_value
                            else:
                                row[comment_column] = append_value
                        else:
                            ace_table = ace_table
            ace_table = json.dumps(ace_table) 
            return ace_table
    except Exception as e:
        logging.error(f"Error in TableAppendDB function")
        logging.error(e)
        return original_ace_table


@register_method
def dotablerowcompare(self,parameters):
    """ 
      'parameters':{
        'Table:{'source':'input_config','table':'ocr','column':'Table'},
        'table_column':'comments'
        'column1':'',
        'operator1':'',
        'column2':'',
        'operator2':'',
        'compare_value':''  
    }

    'returns':
        ace table with comments added
    # """
    
    logging.info(f"parameters got for tablerowcompare are {parameters}")
    

    ace_table = self.get_param_value(parameters['Table'])
    append_value = self.get_param_value(parameters['append_value'])
    table_column = parameters['table_column']
    column1 = parameters['column1']
    operator1 = parameters['operator1']
    column2 =  parameters['column2']
    operator2 = parameters['operator2']
    column3 = parameters['column3']
    operator3 = parameters['operator3']
    right_param = parameters['compare_value']
    original_ace_table = copy.deepcopy(ace_table)
    try:  
        if not ace_table:
            ace_table = []
            table_data = {}
            return ace_table
        else:
            ace_table = json.loads(ace_table)
            table_data = ace_table[0]
            if "rowData" not in table_data:
                logging.debug(f"RowData is empty for ace_table")
            else:
                rows = table_data['rowData']
                if not rows:
                    logging.debug(f"rows is empty for ace_table")
                else:
                    for i,row in enumerate(rows):
                        logging.info(f"eval(str(row[column1])+operator1+ str(row[column2]))")
                        left_param = eval(str(row[column1])+operator1+ str(row[column2])+operator2+str(row[column3]))
                        logging.info(f"left param is : {left_param}")
                        logging.info(f"eval(str(left_param) + " "+operator2+ " "+ str(right_param))")
                        is_bool = eval(str(left_param) + " "+operator3+ " "+ str(right_param))
                        logging.info(f"is bool is: {is_bool}")
                        if is_bool:
                            if row[table_column]!= '':
                                logging.info(f"row table column 66666666666666666666666 {row[table_column]}")
                                row[table_column]=row[table_column] + ", "+ append_value
                                #ace_table[0]['rowData'][0][table_column] = row[table_column]
                                #logging.info(f"ace table of 000000000n is {ace_table}")
                                logging.info(f"in if with 555555555555 {row[table_column]}")
                            else:
                                logging.info(f"where am iiiiiiiiiiiiiiiiiiii")
                                row[table_column] = append_value
                        else:
                            logging.info(f"else what can i do nowwwwwwwwwwwww")
                            ace_table = ace_table
            ace_table = json.dumps(ace_table) 
            logging.info(f"else what can i do00000000000000")
            return ace_table
    except Exception as e:
        logging.error(f"Error in tablerowcompare function")
        logging.error(e)
        return original_ace_table



@register_method
def doCompareTableColumntrue(self,parameters):
    """ 
      'parameters':{
        'Table:{'source':'input_config','table':'ocr','column':'Table'},
        'table_column':'GST Rate'
    }
    """
    logging.info(f"parameters got for CompareTableColumn are {parameters}")

    ace_table = self.get_param_value(parameters['Table'])
    table_column = parameters['table_column']
    value = []
    try:  
        ace_table = json.loads(ace_table)
        table_data = ace_table[0]
        if "rowData" not in table_data:
            logging.debug(f"RowData is empty for ace_table")
        else:
            rows = table_data['rowData']
            if not rows:
                logging.debug(f"rows is empty for ace_table")
            else:
                for i,row in enumerate(rows):
                    value.append(row[table_column])
                value = [i for i in value if i] 
                if len(value) == 0:
                    return False
                else:
                    return True
    except Exception as e:
        logging.error(f"Error in CompareTableColumn function")
        logging.error(e)
        return False


@register_method
def doCompareTableColumn(self,parameters):
    """ 
      'parameters':{
        'Table:{'source':'input_config','table':'ocr','column':'Table'},
        'table_column':'GST Rate'
    }
    """
    
    logging.info(f"parameters got for CompareTableColumn are {parameters}")

    ace_table = self.get_param_value(parameters['Table'])
    table_column = parameters['table_column']
    value = []
    try:  
        ace_table = json.loads(ace_table)
        table_data = ace_table[0]
        if "rowData" not in table_data:
            logging.debug(f"RowData is empty for ace_table")
        else:
            rows = table_data['rowData']
            if not rows:
                logging.debug(f"rows is empty for ace_table")
            else:
                for i,row in enumerate(rows):
                    value.append(row[table_column])
                value = [i for i in value if i] 
                if len(value) == 0:
                    return True
                else:
                    return False
    except Exception as e:
        logging.error(f"Error in CompareTableColumn function")
        logging.error(e)
        return False


@register_method
def doTableAppendDB(self,parameters):
    """ 
      'parameters':{
        'Table:{'source':'input_config','table':'ocr','column':'Table'},
        'table_column':'comments'
    }

    'returns':
        ace table with comments added
    # """
    
    logging.info(f"parameters got for TableAppendDB are {parameters}")

    ace_table = self.get_param_value(parameters['Table'])
    append_value = self.get_param_value(parameters['append_value'])
    table_column = parameters['table_column']
    original_ace_table = copy.deepcopy(ace_table)
    logging.info(f'type of acetable is : {type(ace_table)}')
    try:  
        if not ace_table:
            ace_table = []
            table_data = {}
            return ace_table
        else:
            ace_table = json.loads(ace_table)
            table_data = ace_table[0]
            if "rowData" not in table_data:
                logging.debug(f"RowData is empty for ace_table")
            else:
                rows = table_data['rowData']
                if not rows:
                    logging.debug(f"rows is empty for ace_table")
                else:
                    for i,row in enumerate(rows):
                        if row[table_column]!= '':
                            row[table_column]= row[table_column]+', '+append_value
                        else:
                            row[table_column] = append_value   
            ace_table = json.dumps(ace_table)
            logging.info(f'ace table issssssssssss:{ace_table}')
            return ace_table
    except Exception as e:
        logging.error(f"Error in TableAppendDB function")
        logging.error(e)
        return original_ace_table



@register_method
def doColSum(self, parameters):
    """ Returns sum of the column from inner table
    'parameters': {
        'Table':{'source':'input_config', 'table':'ocr', 'column': 'End_date'},
        'Column':''
        }
        """
    try:
        logging.info(f"parameters got are {parameters}")
        Table=self.get_param_value(parameters['Table'])
        Column=parameters['Column']
        logging.info(f"Table got are {(Table)}")
        try:
            Table=json.loads(Table)
            logging.info(f"The table is {Table}")
        except:
            logging.info(f"The table is {Table}")
        val_list=[]
        col_sum=0
        rowData=Table[0]['rowData']
        for each in rowData:
            tab_col=each[Column]
            val_list.append(tab_col)
            #val_list.append(float(tab_col))
        logging.info(f'value list of col sum is: {val_list}')
        for val in val_list:
            col_sum=col_sum+float(val)
        col_sum=round(col_sum,2)
        col_sum=str(col_sum)
        return col_sum
    except Exception as e:
        logging.error("Failed in extracting sum of the column values")
        logging.error(e)
        return ""

@register_method
def doTableErrorMessages(self, parameters):
    """
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        'parameters': {
            'error_message':{'column1':['message'], 'column2':['message']},
            'input_fields' :[{"field":"Table"}]
            }
    """
    logging.info(f"parameters got for TableErrorMessages are {parameters}")
    error_message = parameters['error_message']
    input_fields = parameters['input_fields']
    description  = parameters['description']
    #error_value = self.get_param_value(parameters['error_value'])
   
    '''if error_value:
        error_message = str(error_value) +' '+ error_message
    logging.info(f'new error message is{error_message}')'''
    
    try:
        validation_dict = {
                            str(self.start_rule_id):{
                                'description' : description,
                                'output' : "",
                                'error_message': error_message,
                                'input' : input_fields
                                }
                            }
        self.validation_params.update(validation_dict)
        self.validation_data.append(validation_dict)
        self.validations_required = True
    except Exception as e:
        logging.error(f"assigning of validation params failed")
        logging.error(e)
    return True
 


@register_method
def doGetLength(self, parameters):
    """Returns the lenght of the parameter value.
    Args:
        parameters (dict): The parameter from which the needs to be taken. 
    eg:
       'parameters': {'param':{'source':'input', 'value':5},
                      }
    Note:
        1) Recursive evaluations of rules can be made.
    
    """
    try:
        value = len(self.get_param_value(parameters['param']))
    except Exception as e:
        logging.error(e)
        logging.error(f"giving the defalut lenght 0")
        value = 0
    return value

@register_method
def doGetRange(self, parameters):
    """Returns the parameter value within the specific range.
    Args:
        parameters (dict): The source parameter and the range we have to take into. 
    eg:
       'parameters': {'value':{'source':'input', 'value':5},
                        'range':{'start_index': 0, 'end_index': 4}
                      }
    Note:
        1) Recursive evaluations of rules can be made for the parameter value.
        2) Range is the python range kind of (exclusive of the end_index)
    """
    logging.info(f"parameters got are {parameters}")
    value = self.get_param_value(parameters['value'])
    range_ = parameters['range']
    start_index = range_['start_index']
    end_index = range_['end_index']
    try:
        logging.info(f"Value got in given index is : {str(value)[start_index: end_index]}")
        return (str(value)[start_index: end_index])
    except Exception as e:
        logging.error(f"some error in the range function")
        logging.error(e)
    return ""

@register_method
def doSelect(self, parameters):
    """Returns the vlookup value from the tables.
    Args:
        parameters (dict): The table from which we have to select and the where conditions. 
    eg:
        'parameters': {
            'from_table': 'ocr',
            'select_column': 'highlight',
            'lookup_filters':[
                {
                    'column_name': 'Vendor GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
                {
                    'column_name': 'DRL GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
            ]
        }
    Note:
        1) Recursive evaluations of rules can be made for the parameter value.
        2) Its like vlook up in the dataframe and the from_table must have the primary key...case_id.
    """
    logging.info(f"parameters got are {parameters}")
    from_table = parameters['from_table']
    column_name_to_select = parameters['select_column']
    lookup_filters = parameters['lookup_filters']

    # convert the from_table dictionary into pandas dataframe
    try:
        master_data = self.data_source[from_table]
    except Exception as e:
        logging.error(f"data source does not have the table {from_table}")
        logging.error(e)
        master_data = {}

    master_df = pd.DataFrame(master_data) 

    # build the query
    query = ""
    for lookup in lookup_filters:
        lookup_column = lookup['column_name']
        compare_value = self.get_param_value(lookup['compare_with'])
        query += f"`{lookup_column}` == '{compare_value}' & "
    query = query.strip(' & ') # the final strip for the extra &
    logging.info(f'query in do select is {query}')
    result_df = master_df.query(query)
    result_df = result_df.reset_index(drop=True)

    # get the wanted column from the dataframe
    if not result_df.empty:
        try:
            return result_df[column_name_to_select][0] # just return the first value of the matches
        except Exception as e:
            logging.error(f"error in selecting the required data from the result")
            logging.error(e)
            return ""

@register_method
def doSelectcase(self, parameters):
    """Returns the vlookup value from the tables.
    Args:
        parameters (dict): The table from which we have to select and the where conditions. 
    eg:
        'parameters': {
            'from_table': 'ocr',
            'select_column': 'highlight',
            'lookup_filters':[
                {
                    'column_name': 'Vendor GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
                {
                    'column_name': 'DRL GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
            ]
        }
    Note:
        1) Recursive evaluations of rules can be made for the parameter value.
        2) Its like vlook up in the dataframe and the from_table must have the primary key...case_id.
    """
    logging.info(f"parameters got are {parameters}")
    from_table = parameters['from_table']
    column_name_to_select = parameters['select_column']
    lookup_filters = parameters['lookup_filters']

    # convert the from_table dictionary into pandas dataframe
    try:
        master_data = self.data_source[from_table]
    except Exception as e:
        logging.error(f"data source does not have the table {from_table}")
        logging.error(e)
        master_data = {}

    master_df = pd.DataFrame(master_data) 

    # build the query
    query = ""
    for lookup in lookup_filters:
        lookup_column = lookup['column_name']
        master_df[lookup_column]  =   master_df[lookup_column].str.lower()
        compare_value = self.get_param_value(lookup['compare_with'])
        compare_value =   str(compare_value).lower()
        query += f"`{lookup_column}` == '{compare_value}' & "
    query = query.strip(' & ') # the final strip for the extra &
    logging.info(f'query in do select is {query}')
    result_df = master_df.query(query)
    result_df = result_df.reset_index(drop=True)

    # get the wanted column from the dataframe
    if not result_df.empty:
        try:
            return result_df[column_name_to_select][0] # just return the first value of the matches
        except Exception as e:
            logging.error(f"error in selecting the required data from the result")
            logging.error(e)
            return ""


@register_method
def doTransform(self, parameters) :
    """Returns the evalated data of given equations
    Args:
        parameters (dict): The source parameter which includes values and operators.
    eg:
        'parameters':[
            {'param':{'source':'input', 'value':5}},
            {'operator':'+'},
            {'param':{'source':'input', 'value':7}},
            {'operator':'-'},
            {'param':{'source':'input', 'value':1}},
            {'operator':'*'},
            {'param':{'source':'input', 'value':3}}
        ]
    Note:
        1) Recursive evaluations of rules can be made.
    """
    equation = ''
    logging.info(f"parameters got are {parameters}")
    for dic in parameters :
        for element,number_operator in dic.items() :
            if element == 'param' :
                value = f'{self.get_param_value(number_operator)}'
                value = str(value).replace(',','').replace('INR','').replace('RUPEES','').replace('inr','').replace('rupees','').replace('rupee','').replace('RUPEE','').replace(' ','').replace(':','').replace('%','')
            elif element == 'operator' :
                value = f' {number_operator} '
        equation = equation + value
    logging.info(f"equation is : {equation}")    
    print('Equation is:',equation)
    try:
        equation = (eval(equation))
    except Exception as e:
        equation = 0
        logging.info(f'some value is empty in equation,so final value is 0')
        logging.info(e)
    equation = str(round(equation))
    logging.info(f'value after str and round is {equation}')
    return equation

@register_method
def doContains(self, parameters):
    """ Returns true value if the data is present in the data_source
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
            cpt_check_rule = {'rule_type': 'static',
                'function': 'Contains',
                'parameters': { 'table_name': 'ocr','column_name': 'cpt_codes',
                                'value':{'source':'input', 'value':92610}
                        }
            }
    """
    logging.info(f"parameters got are {parameters}")
    table_name = parameters['table_name']
    column_name = parameters['column_name']
    value = self.get_param_value(parameters['value'])
    logging.info(f"Value got is : {value}")
    column_values = self.data_source[table_name]
    print(type(column_values),column_values)
    if value in self.data_source[table_name][column_name]:
        return True
    else :
        return False

@register_method
def doContainsMaster(self, parameters):
    """ Returns true value if the data is present in the data_source
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
            cpt_check_rule = {'rule_type': 'static',
                'function': 'Contains',
                'parameters': { 'table_name': 'ocr','column_name': 'cpt_codes',
                                'value':{'source':'input', 'value':92610}
                        }
            }
    """
    logging.info(f"parameters got are {parameters}")
    table_name = parameters['table_name']
    column_name = parameters['column_name']
    value = self.get_param_value(parameters['value'])
    print(value)
    df = pd.DataFrame(self.data_source[table_name])
    print(list(df[column_name]))
    if str(value) in list(df[column_name].astype(str)):
        return True
    else :
        return False

@register_method
def doCount(self, parameters):
    """Returns the count of records from the tables.
    Args:
        parameters (dict): The table from which we have to select and the where conditions. 
    eg:
        'parameters': {
            'from_table': 'ocr',
            'lookup_filters':[
                {
                    'column_name': 'Vendor GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
                {
                    'column_name': 'DRL GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
            ]
        }
    Note:
        1) Recursive evaluations of rules can be made for the parameter value.
        2) Its like vlook up in the dataframe and the from_table must have the primary key...case_id.
    """
    logging.info(f"parameters got are {parameters}")
    from_table = parameters['from_table']
    lookup_filters = parameters['lookup_filters']

    # convert the from_table dictionary into pandas dataframe
    try:
        master_data = self.data_source[from_table]
    except Exception as e:
        logging.error(f"data source does not have the table {from_table}")
        logging.error(e)
        master_data = {}

    master_df = pd.DataFrame(master_data) 

    # build the query
    query = ""
    for lookup in lookup_filters:
        lookup_column = lookup['column_name']
        compare_value = self.get_param_value(lookup['compare_with'])
        query += f"{lookup_column} == {compare_value} & "
    query = query.strip(' & ') # the final strip for the extra &
    result_df = master_df.query(query)

    # get the wanted column from the dataframe
    if not result_df.empty:
        try:
            return len(result_df) # just return the first value of the matches
        except Exception as e:
            logging.error(f"error in selecting the required data from the result")
            logging.error(e)
            return 0
    else:
        return 0

@register_method
def doProduceData(self, parameters):
    """Updates the data that needs to be sent to next topic via kafka.
    Args:
        parameters (dict): The parameter from which the needs to be taken. 
    eg:
       'parameters': {'key':{'source':'input', 'value':5},
                        'value': {'source':'input', 'value':5}
                      }
    Note:
        1) Recursive evaluations of rules can be made.
    
    """
    try:
        kafka_key = self.get_param_value(parameters['key'])
        kafka_value = self.get_param_value(parameters['value'])
        # update the self.kafka data
        self.kafka_data[kafka_key] = kafka_value
    except Exception as e:
        logging.error(e)
        logging.error(f"Unable to send the data that needs to be sent to next topic via kafka.Check rule")
    return True


######################################### HSBC ##################################################
def file_manager_folder_id_updates(db, case_id, folder_id_mapping):
    query = f"select id, folder_id from file_manager where case_id = '{case_id}'"
    file_manager_db = db.execute(query)
    for i,j in file_manager_db.iterrows():
        print(int(file_manager_db['folder_id'][i]))
        old_value = int(file_manager_db['folder_id'][i])
        if old_value in folder_id_mapping:
            new_value = folder_id_mapping[old_value]
            update_query = f"update file_manager set folder_id = {new_value} where case_id ='{case_id}' and folder_id = {old_value}"
            db.execute(update_query)
    return True

def insert_update_records_(db, input_data, case_id):
    try:
        max_id_query = f"SELECT max(id) from folder_manager"
        parent_id = db.execute_default_index(max_id_query)
        start_id = list(parent_id['max(id)'])[0]+1
        folder_id_mapping = {}
        for button_id,unique_keys in input_data.items():
            get_parent_id_query = f"SELECT * from folder_manager WHERE unique_key=%s"
            params = [button_id]
            df = db.execute(get_parent_id_query, params=params)
            parent_id = df.index.values[0]
            logging.info(f"parent_id got is {parent_id}")  
            for unique_key in unique_keys:
                query = f"SELECT * from folder_manager WHERE unique_key=%s"
                params = [unique_key]
                try:
                    df = db.execute(query, params=params)
                    old_folder_id = df.index.values[0]
                    new_unique_key = str(unique_key)+'_'+str(button_id)
                    logging.info(f"new_unique_key got is {new_unique_key}")
                    folder_name = list(df['folder_name'])[0]
                    logging.info(f"folder got is {folder_name}")
                    insert_query = f"INSERT INTO `folder_manager` VALUES ('{start_id}', '{new_unique_key}', '{folder_name}', '{parent_id}')"
                    db.execute(insert_query)
                    folder_id_mapping[old_folder_id] = start_id
                    start_id += 1
                    
                except Exception as e:
                    logging.error("Unable into insert the new record")
                    logging.error(str(e))
                    
    except Exception as e:
        print (e)
        return False
    print (folder_id_mapping)
    
    try:
        # update the values in the file_manager
        file_manager_folder_id_updates(db, case_id, folder_id_mapping)
        
    except Exception as e:
        # ask mahendra
        logging.error("update is not happening")
        logging.error(e)
    
    return True

@register_method
def doFileManagerUpdate(self, parameters):
    """ 
        Generate Case Reference number.
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        update_records =  {'rule_type': 'static',
                                 'function': 'FileManagerUpdate',
                                 'parameters': {'database':{'source':'input','value':"file_manager"}, 
                                        'input_data':{'source':'input', 'value':{8:["uploads", "email"], 9:["uncategorized"]}
                            },
                      }
    }
    """
    logging.info(f"parameters got are {parameters}")
    database = self.get_param_value(parameters['database'])
    input_data = self.get_param_value(parameters['input_data'])
    db = DB(database, tenant_id=self.tenant_id, **db_config)
    return insert_update_records_(db, input_data, self.case_id)

@register_method
def docase_gen(self, parameters):
    """ 
        Generate Case Reference number.
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        case_ref_generation =  {'rule_type': 'static',
                                 'function': 'case_gen',
                                 'parameters': {'code':{'source':'input','value':"LEA"}, 
                                        'auth':{'source':'rule', 'value':authortiy_rule},
                                        'id':{'source':'input','value':1}
                      }
    }
    """
    logging.info(f"parameters got are {parameters}")
    code = self.get_param_value(parameters["code"])
    authority = self.get_param_value(parameters["auth"])
    #ID = self.get_param_value(parameters["id"])
    #ID.zfill(2)
    """ID = ID.split("-")
    ID = ID[1]"""
    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
    query_ocr = "Select * from `ocr`"
    ocr_extracted = ocr_db.execute(query_ocr)
    logging.info("extraction of ocr is done")
    ocr_df = pd.DataFrame(ocr_extracted)
    ID = len(ocr_df)
    ID = str(ID).zfill(3)
    print("###### In case reference generation function ######")
    try:
        today = date.today()
        today = today.strftime(f"%d%m%y")
        case_ref = code+"-"+authority+"-"+today+"-"+ID
        print(f'generated Casereference _number is : ',case_ref)
        return case_ref
    except Exception as e:
        logging.error("Cannot Generate Case Reference number ")
        logging.error(e)
        return False

@register_method
def doAuthority(self, parameters):

    """ 
        Get Authority in Shortform.
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        authortiy_rule = {'rule_type': 'static',
                        'function': 'authority',
                        'parameters': {'authoritie':{'source':'input','value':"Enforcement Directorate"}, 
                      }
    }   
    """
    logging.info(f"parameters got are {parameters}")
    auth = self.get_param_value(parameters["authoritie"])
    mail = self.get_param_value(parameters["mail"])
    try:
        if mail or mail == 'true':
                auth = "EML"
        else:
            if auth == "Enforcement Directorate":
                auth = "ED"
            elif auth == "Economic Offences Wing":
                auth = "EOW"
            elif auth == "National Investigation Agency":
                auth = "NIA"
            elif auth == "Central Bureau of Investigation":
                auth = "CBI"
            elif auth == "Income Tax Department":
                auth = "ITD"
        print(auth)
        return auth
    except Exception as e:
        logging.error(f"Cannot Generate Case Reference number ERROR : in doAuthority_function")
        logging.error(e)
        return False

@register_method
def Dodue_date_generate(self, parameters):
    """ 
        Due_Date_generation.
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        duedate_rule = {'rule_type': 'static',
                        'function': 'due_date_generate',
                        'parameters': {'Extended_days':{'source':'input_config','table':"ocr",'column':'Default Extension'}, 
                      }
    }   
    """
    logging.info(f"parameters got are {parameters}")
    holidays = self.get_param_value(parameters["holidays"])
    Extended_days = self.get_param_value(parameters["Extended_days"])
    print(f'Extended_days',Extended_days)
    print("=====================>")
    print(holidays)
    Extended_days,_ = Extended_days.split(" ")
    Extended_days = int(Extended_days)
    try:
        today = date.today()
        due_date = today + timedelta(days = int(Extended_days))
        print(f'due_date is :',due_date)
        while True:
            if str(due_date) not in holidays :
                print(f'due_date2 is :',due_date)
                return due_date
            else:
                due_date = due_date + timedelta(days = 1)
                print(f'due_date3 is :',due_date)
    except Exception as e:
        logging.error(f"=======> Cannot Generate DueDate_generate ERROR : in Dodue_date_generate_function")
        logging.error(e)
        return False

@register_method
def BankDodue_date_generate(self, parameters):
    """ 
        Bank_Due_Date_generation.
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        duedate_rule = { 'rule_type': 'static',
        'function': 'Bank_due_date_generate',
        'parameters': {'Due_date':{'source':'input_config','table':"ocr",'column':'Due Date(Notice)'}
        }
    }
    """
    holidays = self.get_param_value(parameters["holidays"])
    print(holidays)
    logging.info(f"parameters got are {parameters}")
    Due_date = self.get_param_value(parameters["Due_date"])
    Receipt_time = self.get_param_value(parameters["Receipt_time"])
    try:
        today = date.today()
        today_time = datetime.today()
        date_format = "%Y-%m-%d"
        a = datetime.strptime(str(today), date_format)
        b = datetime.strptime(str(Due_date), date_format)
        diff_days = (b - a).days
        print(f'diff_days are =====> ',diff_days)
        Due_date_date = datetime.strptime(str(Due_date),"%Y-%m-%d").date()
        if diff_days == 0 or diff_days == -1 or diff_days == 1 or diff_days == 2 or diff_days == 3 :
            Due_date1 = date.today()
            todaydate = datetime.now()
            Receipt_time = datetime.strptime(Receipt_time,"%Y-%m-%d %H:%M:%S")
            today12pm = todaydate.replace(hour=12, minute=0, second=0, microsecond=0)
            if Receipt_time > today12pm:
                Due_date1 = today + timedelta(days = 1)
            else:
                Due_date1 = date.today()
        elif diff_days == 7 :
            Due_date1 = Due_date_date - timedelta(days = 2)
        elif diff_days == 15 or diff_days == 16 :
            Due_date1 = Due_date_date - timedelta(days = 3)
        elif diff_days >= 17 :
            Due_date1 = today + timedelta(days = 15)
        else:
            Due_date1 = Due_date_date - timedelta(days = 2)
        print(f'Duedate in Bank_is ===> ',Due_date1 )

        while True:
            if str(Due_date1) not in holidays :
                print(f'Bank_Due_date is ======> ',Due_date1)
                return str(Due_date1)
            else:
                Due_date1 = Due_date1 - timedelta(days = 1)
        print(f'Bank_Due_date is ======> ',Due_date1)
    except Exception as e:
        logging.error(f"===========>Cannot Generate BankDodue_date_generate ERROR : in BankDodue_date_generate_function")
        logging.error(e)
        return False

@register_method
def doSat_and_sun_holidays(self, parameters):

    """ 
        holidays generation.
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        dosat_sun_rule = {'rule_type': 'static',
                        'function': 'dosat_sun_generate',
                        'parameters': {'Extended_days':{'source':'input_config','table':"ocr",'column':'Default Extension'}, 
                      }
    }   
    """
    logging.info(f"parameters got are {parameters}")
    try:
        year = int(datetime.now().year)
        print(f"year is : ",year)
        def all_sundays(year):
        # January 1st of the given year
            dt1 = date(year, 1, 1)
        # First Sunday of the given year  
            print("########## in all_sundays function ")     
            dt1 += timedelta(days = 6 - dt1.weekday())
            while dt1.year == year:
                yield dt1
                dt1 += timedelta(days = 7)
        years1=[]
        for s in all_sundays(year):
            years1.append(str(s))
        print(f'all_sundays are',years1)

        def second_saturdays(year):
            dt2 = date(year, 1, 1) 
            dt2 += timedelta(days = 5 - dt2.weekday()) 
            while dt2.year == year:
                if 8 <= dt2.day <= 14 :
                    yield dt2
                dt2 += timedelta(days = 7)
        years2=[]
        for s2 in second_saturdays(year):
            years2.append(str(s2))
        print(f'all_second_saturdays are',years2)

        def fourth_saturdays(year):
            dt3 = date(year, 1, 1) 
            dt3 += timedelta(days = 5 - dt3.weekday()) 
            while dt3.year == year:
                if 22 <= dt3.day <= 28 :
                    yield dt3
                dt3 += timedelta(days = 7)
        years3=[]
        for s3 in fourth_saturdays(year):
            years3.append(str(s3))
        print(f'all_fourth_saturdays are',years3)
    except Exception as e:
        logging.error(f"Cannot Generate Holiday_list ERROR : in sat_sun_holiday_generate_function")
        logging.error(e)
        return False

    Holiday_list = years1+years2+years3
    print(Holiday_list)
    return Holiday_list

@register_method
def get_holidays_fromdatabase(self, parameters):
    logging.info(f"parameters got are {parameters}")
    from_table1 = self.get_param_value(parameters['from_table1'])
    from_column1 = self.get_param_value(parameters['from_column1'])
    sun_sat_holidays_list = self.get_param_value(parameters['sun_sat_holidays'])
    try:
        holidays_df = (self.data_source[from_table1])
        print(holidays_df)
        print("============= @ ========================>")
        holidays_df = pd.DataFrame(holidays_df)
        holidays_df[from_column1] = holidays_df[from_column1].astype(str)
        holidays_df[from_column1] =  pd.to_datetime(holidays_df[from_column1],dayfirst=True,errors='coerce').dt.strftime('%Y-%m-%d')
        holidays_list = holidays_df[from_column1].tolist()
        print(holidays_list)
        total_holidays = holidays_list + sun_sat_holidays_list
        print(f'total_holidays are:',total_holidays)
        return total_holidays
    except Exception as e:
        logging.error(f"=========> Error in Adding Holidays ")
        logging.error(e)        

@register_method
def doContainsAccount_GHO(self, parameters):
    """ Returns assigned value if the data is present in the data_source
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        { 'rule_type':'static',
        'function': 'ContainsAccount_GHO',
        'parameters' : {
                        'table_name_ocr': 'ocr',
                        'map_column':'Mapping Table',
                        'column1_map_id': 'Customer ID',
                        'column2_map_to': 'Account Number',
                        'table_name_acc': 'close_account_dump',
                        'column1_acc_id': 'CUSTOMER_ID',
                        'column2_acc_to': 'ACCOUNT_NO',
                        'value1':{'source':'input_config', 'table':'ocr', 'column': 'Mapping Table'},
                        }
        }
        """
    logging.info(f"parameters got are {parameters}")
    table_name_ocr = parameters['table_name_ocr']
    map_column = parameters['map_column']
    column1_map_id =  parameters['column1_map_id']
    column2_map_to =  parameters['column2_map_to']
    table_name_acc =  parameters['table_name_acc']
    column1_acc_id =  parameters['column1_acc_id']
    column2_acc_to =  parameters['column2_acc_to']
    value_map = self.get_param_value(parameters['value1'])
    print(table_name_ocr)
    print(table_name_acc)
    try:
        print(type(value_map))
        value_map = json.loads(value_map)
        dict_list = []
        map_dict = [dict_list.append(e) for e in value_map[0]["rowData"]]
        map_df = pd.DataFrame(dict_list)
        df_acc = self.data_source[table_name_acc]
        df_acc = pd.DataFrame(df_acc)
        if (column2_map_to == 'Account Number') or (column2_map_to == 'GHO Code'):
            for index, row in map_df.iterrows():
                for indexer, rows in df_acc.iterrows():
                    if row[column1_map_id] == rows[column1_acc_id]:
                        if row[column2_map_to] == '':
                            row[column2_map_to] = rows[column2_acc_to]
            print(map_df)
            map_dict = map_df.to_dict(orient = 'records')
            for i in range(map_df['Customer ID'].count()):
                value_map[0]["rowData"][i][column2_map_to] = map_dict[i][column2_map_to]
            value_map = json.dumps(value_map)
            #self.data_source[table_name_ocr][map_column] = value_map
            return value_map
        else:
            for index, row in map_df.iterrows():
                for indexer, rows in df_acc.iterrows():
                    if row[column1_map_id] == rows[column1_acc_id]:
                        row[column2_map_to] = rows[column2_acc_to]
            print(map_df)
            map_dict = map_df.to_dict(orient = 'records')
            for i in range(map_df['Customer ID'].count()):
                value_map[0]["rowData"][i][column2_map_to] = map_dict[i][column2_map_to]
            value_map = json.dumps(value_map)
            #self.data_source[table_name_ocr][map_column] = value_map
            return value_map
    except Exception as e:
        logging.error(f"Error in ===============> doContainsAccount_GHO Function")
        logging.error(e)
        return value_map

@register_method
def doContains_UCIC(self, parameters):
    """ Returns BOOLEAN value if the data is present in the data_source
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        { 'rule_type':'static',
        'function': 'Contains_UCIC',
        'parameters' : {
                        'column1_map_id': 'Customer ID',
                        'table_name_acc': 'close_account_dump',
                        'column1_acc_id': 'CUSTOMER_ID',
                        'value1':{'source':'input_config', 'table':'ocr', 'column': 'Mapping Table'},
                        }
        }
        """
    logging.info(f"parameters got are {parameters}")
    column1_map_id =  parameters['column1_map_id']
    table_name_acc =  parameters['table_name_acc']
    column1_acc_id =  parameters['column1_acc_id']
    value_map = self.get_param_value(parameters['value1'])
    print(value_map)
    print(table_name_acc)
    try:
        dict_list = []
        value_map = json.loads(value_map)
        map_dict = [dict_list.append(e) for e in value_map[0]["rowData"]]
        map_df = pd.DataFrame(dict_list)
        df_acc = self.data_source[table_name_acc]
        df_acc = pd.DataFrame(df_acc)
        print(df_acc)
        id_list = list(df_acc[column1_acc_id])
        print(id_list)
        for index, row in map_df.iterrows():
            if row[column1_map_id] in id_list :
                return 'Match Found'
        return 'Match Not Found'       
    except Exception as e:
        logging.error(f"Error in ===============> doContains_UCIC Function")
        logging.error(e)
        return False

@register_method
def alnum_and_contains(self, parameters):
    """    
        'paramaters':{
                    'from_table':'ocr',
                    'columns':''
        }

    """
    logging.info(f"parameters got are {parameters}")
    from_table = parameters['from_table']
    column_name = parameters['column']
    value = self.get_param_value(parameters['value'])

    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
    query_ocr = "Select * from `ocr`"
    ocr_extracted = ocr_db.execute(query_ocr)
    logging.info("extraction of ocr is done")
    ocr_df = pd.DataFrame(ocr_extracted)
    ocr_df[column_name] = ocr_df[column_name].str.strip()              
    ocr_df[column_name] = ocr_df[column_name].str.replace(r"[^a-zA-Z\d]+", "")
    value = re.sub(r"[^a-zA-Z\d]+", "",value)
    print(value)
    print(ocr_df[column_name])
    print(list(ocr_df[column_name]).count(str(value)))
    if list(ocr_df[column_name]).count(str(value)) > 1:
        print('True')
        return True
    else :
        print('False')
        return False

@register_method
def doFindDuplicateID(self, parameters):
    """ Returns Dupilcate id value if the ID is present in the ocr
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
       """
    logging.info(f"parameters got are {parameters}")
    Reference_number_in = self.get_param_value(parameters['Reference_number'])
    column_drop = parameters['column_drop']
    data = self.get_param_value(parameters['data'])
    #ocr_extracted = self.data_source['ocr_tot']
    try:
        try:
            ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            query_ocr = "Select * from `ocr`"
            ocr_extracted = ocr_db.execute(query_ocr)
            logging.info("extraction of ocr is done")
            ocr_df = pd.DataFrame(ocr_extracted)
            ocr_df.drop( ocr_df[ ocr_df[column_drop] == Reference_number_in ].index , inplace=True)
            master_dict = {}
            for index ,rows in ocr_df.iterrows():
                if rows['Mapping Table']:
                    Customer_ids_list=[]
                    Customer_ids_map = json.loads(rows['Mapping Table'])
                    print(Customer_ids_map[0]["rowData"])
                    try:
                        map_dict = [Customer_ids_list.append(cid['Customer ID']) for cid in Customer_ids_map[0]["rowData"]]
                        ref_key = rows[column_drop]
                        print(Customer_ids_list,ref_key)
                        master_dict.update({ref_key :  Customer_ids_list})
                    except Exception as e:
                        print(e)
        except Exception as e:
            logging.info(f"Error in Generating all case_id's dict")
            logging.info(e)

        dict_list = []
        value_map = json.loads(data)
        map_dict = [dict_list.append(e['Customer ID']) for e in value_map[0]["rowData"]]
        print(dict_list)
        for c_id in dict_list:
            for key,value in master_dict.items():
                if c_id in value:
                    print(f'Reference number is =========>',key)
                    self.data_source['ocr']['Duplicate Case Reference Number'] = key
                    return True

    except Exception as e:
        logging.info('Error in DuplicateID function')
        logging.info(e)
        
########################################################## IndusIND #######################################################################

@register_method
def doFindDuplicates(self, parameters):
    """  Finds duplicate rows based on the columns mentioned, returns true if duplicates exists
        'paramaters':{
                    'from_table':'ocr',
                    'columns':['','']
        }

        NOTE : works only for columns in single datatable
    """
    logging.info(f"parameters got are {parameters}")
    from_table = parameters['from_table']
    filter_columns = parameters['columns']

    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
    query_ocr = "Select * from `ocr`"
    ocr_extracted = ocr_db.execute(query_ocr)
    logging.info("extraction of ocr is done")
    for column in filter_columns:
        try:
            compare_value = self.data_source[from_table][column]
            ocr_extracted = ocr_extracted[ocr_extracted[column].astype(str) == str(compare_value)]
        except Exception as e:
            logging.error("dataframe filter failed")
            logging.error(e)
    
    logging.info(f"filtered df is {ocr_extracted}")
    if len(ocr_extracted) > 1:
        return True
    else:
        return False

@register_method
def doFindDuplicatesTables(self, parameters):
    """ Finds duplicate rows based on the columns mentioned, returns true if duplicates exists
        'paramaters':{
                    'duplicate_columns':['',''],
                    'merge_column':''
        }

       'NOTE': specifically for ocr and process queue 
    """
    logging.info(f"parameters got are {parameters}")
    duplicate_columns = parameters['duplicate_columns']
    merge_column = parameters['merge_column']

    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
    query_ocr = "Select * from `ocr`"
    ocr_extracted = ocr_db.execute(query_ocr)
    logging.info("extraction of ocr is done")
    
    query_process = f"select * from `process_queue`"
    process_queue_db = DB('queues', tenant_id=self.tenant_id, **db_config)
    df_process = process_queue_db.execute(query_process)
    logging.info("extraction of process queue is done")

    merge_df = pd.merge(ocr_extracted,df_process,on=merge_column)

    for column in duplicate_columns:
        try:
            compare_value = merge_df[merge_df['case_id']==self.case_id][column]
            compare_value.reset_index(inplace=True, drop=True)
            merge_df = merge_df[merge_df[column].astype(str) == str(compare_value[0])]
        except Exception as e:
            logging.error("dataframe filter failed")
            logging.error(e)
    
    logging.info(f"filtered df is {ocr_extracted}")
    if len(merge_df) > 1:
        return True
    else:
        return False

@register_method
def doFindTotal(self, parameters):
    """ returns the sum of a column in the ui table
    "parameters":{
        'data':{'source':'input_config','table':'ocr','column':'table'},
        'key_name':'CPT Code'
    }

    """
    logging.info(f"parameters got are {parameters}")
    data = self.get_param_value(parameters['data'])
    key_name = parameters['key_name']
    try:
        
        data = json.loads(data)
        truth_values = ['Indusind' in e[key_name] for e in data[0]["rowData"]]
        amounts = []
        for (values, truth_value) in zip(data[0]["rowData"], truth_values):
            if truth_value:
                amounts.append(int(values['']))
        total = sum(amounts)
        return total
    except Exception as e:
        logging.error(f"connot calculate total amount")
        logging.error(e)
        return ""
        
@register_method
def doDateParsing(self, parameters):
    """Checks whether given date is last day of that month or not, returns true if yes
        parameters:{
            "input_date":{"source":"input_config","table":"ocr","column":"Stock Date"
        }
    """
    logging.info(f"parameters got are {parameters}")
    input_date = self.get_param_value(parameters['input_date'])
    try:
        input_date = input_date.replace('.','-')
        input_date = input_date.replace('/','-')
        input_date = input_date.replace(' ','-')
        input_date = input_date.replace('st','')
        input_date = input_date.replace('th','')
    except:
        input_date = input_date
    
    logging.info(f"date got is {input_date}")
    list_31 = ['jan','mar','may','jul','aug','oct','dec','01','03','05','07','08','10','12','january','	march','may','july','august','october','december','1','3','5','7','8']
    list_30 = ['apr','jun','sep','nov','04','06','09','11','april','june','september','november','4','6','9']
    try:
        input_list = input_date.split("-")
        if len(input_list) == 2:
            if input_list[0].lower() in list_31:
                input_date = "31-"+input_date
            elif input_list[0].lower() in list_30:
                input_date = "30-"+input_date
            else:
                feb_last = calendar.monthrange(int(input_list[1]),2)[1]
                input_date = str(feb_last)+"-"+input_date
        logging.info(f"Converted date is {input_date}")
    except Exception as e :
        logging.error("Cannot convert date")
        logging.error(e)

    try:
        input_date = parser.parse(input_date,default=datetime(2019, 10, 3))
        date_list = str(input_date).split("-")
        input_day = date_list[2][0:2]
        input_month = date_list[1]
        input_year = date_list[0]
        logging.info(f"input date is: {input_day}")
        month_last = calendar.monthrange(int(input_year),int(input_month))[1]
        logging.info(f"last day of given month is {month_last}")
        if str(input_day) == str(month_last):
            logging.info(f"given date and month's last date are same")
            return True
        else:
            logging.info(f"given date and month's last date are different")
            return False
    except Exception as e:
        logging.error("Cannot compare two dates")
        logging.error(e)
        return False

@register_method
def doDateParsingMarch(self, parameters):
    """Checks whether given date is last day of that month or not, returns true if yes
        'parameters':{
            "input_date":{"source":"input_config","table":"ocr","column":"Stock Date"
        }
        NOTE: works same for all months except march, if march returns true for any date
    """
    logging.info(f"parameters got are {parameters}")
    input_date = self.get_param_value(parameters['input_date'])
    try:
        input_date = input_date.replace('.','-')
        input_date = input_date.replace('suspicious','')
        input_date = input_date.replace('/','-')
        input_date = input_date.replace(' ','-')
        input_date = input_date.replace('st','')
        input_date = input_date.replace('th','')
    except:
        input_date = input_date
        
    logging.info(f"date got is {input_date}")
    list_31 = ['jan','may','jul','aug','oct','dec','01','05','07','08','10','12','january','may','july','august','october','december','1','3','5','7','8']
    list_30 = ['apr','jun','sep','nov','04','06','09','11','april','june','september','november','4','6','9']
    try:
        input_list = input_date.split("-")
        if len(input_list) == 2:
            if input_list[0].lower() in list_31:
                input_date = "31-"+input_date
            elif input_list[0].lower() in list_30:
                input_date = "30-"+input_date
            elif(input_list[0].lower()=='march') or (input_list[0].lower()=='mar') or (input_list[0]=='03'):
                print(input_date)
                return True
            else:
                feb_last = calendar.monthrange(int(input_list[1]),2)[1]
                input_date = str(feb_last)+"-"+input_date
        logging.info(f"Converted date is {input_date}")
    except Exception as e :
        logging.error("Cannot convert date")
        logging.error(e)

    try:
        input_date = parser.parse(input_date,default=datetime(2019, 10, 3))
        date_list = str(input_date).split("-")
        logging.info(f"Date list is : {date_list}")
        input_day = date_list[2][0:2]
        input_month = date_list[1]
        if (input_month.lower()=='march') or (input_month.lower()=='mar') or (input_month=='03'):
            return True
        input_year = date_list[0]
        logging.info(f"input date is: {input_day}")
        month_last = calendar.monthrange(int(input_year),int(input_month))[1]
        logging.info(f"last day of given month is {month_last}")
        if str(input_day) == str(month_last):
            logging.info(f"given date and month's last date are same")
            return True
        else:
            logging.info(f"given date and month's last date are different")
            return False
    except Exception as e:
        logging.error("Cannot compare two dates")
        logging.error(e)
        return False

@register_method
def doReplace(self, parameters):
    """ Replaces value in a string and returns the updated value
    'parameters':{
        'data':{'source':'input','value':''},
        'to_replace':{'source':'input','value':''},
        'replace_with':{'source':'input','value':''},
        'space_check':{'source':'input','value':'yes'}//should be used only when we want to replace space with another value
    }
    """
    logging.info(f"parameters got are {parameters}")
    data = self.get_param_value(parameters['data'])
    to_replace = self.get_param_value(parameters['to_replace'])
    replace_with = self.get_param_value(parameters['replace_with'])
    try:
        space_check = self.get_param_value(parameters['space_check'])
    except:
        space_check = ""
    if not space_check:
        try:
            data = str(data).replace(to_replace,replace_with)
            logging.info(f"Data after replacing with {to_replace} is {data}")
            return data
        except Exception as e:
            logging.error("Replacing value failed")
            logging.error(e)
            return data
    else:
        logging.info(f"Data after replacing with space is {str(data).replace(' ','')}")
        return(str(data).replace(" ",""))

@register_method
def doSplit(self, parameters):
    """ Replaces value in a string and returns the required index
    'parameters':{
        'data':{'source':'input','value':''},
        'symbol_to_split':{'source':'input','value':''},
        'required_index':{'source':'input','value':''}
    }
    """
    logging.info(f"parameters got are {parameters}")
    symbol_to_split = self.get_param_value(parameters['symbol_to_split'])
    required_index = self.get_param_value(parameters['required_index'])
    data = self.get_param_value(parameters['data'])
    try:
        data_split = str(data).split(symbol_to_split)
        logging.info(f"splited data is {data_split}")
        return data_split[int(required_index)]
    except Exception as e:
        logging.error("Spliting value failed")
        logging.error(e)
        return data

@register_method
def doAlphaNumCheck(self, parameters):
    """ Returns true value if the string is Alpha or num or alnum
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
         {'rule_type':'static',
        'function': 'Alnum_num_alpha',
        'parameters' :{'word':{'source':'rule','value':get_range_rule1},
                       'option':'alpha',      
        }
        }
    """
    logging.info(f"parameters got are {parameters}")
    word = self.get_param_value(parameters['word'])
    option = parameters['option']
    try:
        if option == 'alpha':
            bool_value = word.isalpha()
            logging.info(f'{word} is alpha {bool_value}')
        if option == 'numeric':
            bool_value = word.isnumeric()
            logging.info(f'{word} is numeric {bool_value}')
        if option == 'alnum':
            bool_value = word.isalnum()
            logging.info(f'{word} is numeric {bool_value}')
        return bool_value
    except Exception as e:
        logging.error("Error In doAlphaNumCheck function")
        logging.error(e)
        return False

@register_method
def doRegexColumns(self, parameters):
    """ Returns a value by applying given Regex pattern on value
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        {'rule_type':'static',
        'function': 'Regex',
        'parameters' :{'table_name':"",
                        'columns':[],
                       'regex_str':"\d{6}"
        }
        }
        NOTE: can apply for more than one column at a single time
    """
    logging.info(f"parameters got are {parameters}")
    
    table_name = parameters['table_name']
    columns = parameters['columns']
    regex_str = parameters['regex_str']
    try:
        regex = re.compile(f'{regex_str}')
    except Exception as e :
        logging.error("Error In regex pattern")
    for column in columns:
        phrase = self.data_source[table_name][column]
        logging.info(f"GOT THE VAlUE FOR COLUMN {column} IS {phrase}")
        if not phrase:
            phrase = '0'
        phrase = str(phrase).replace(",","")
        try:
            matches = re.findall(regex, str(phrase))
            if matches[0]:
                logging.info(f"LIST OF MATCHES GOT ARE : {matches}")
                matches = matches[0]
            else:
                matches = 0
        except Exception as e:
            logging.debug("REGEX MATCH GOT FAILED SO DEFAULT VALUE 0 GOT ASSIGNED")
            matches = 0
        logging.debug(f"MATCHES GOT FOR {column} COLUMN IS : {matches}")
        self.data_source[table_name][column] = str(matches)
        try:
            if table_name not in self.changed_fields:
                self.changed_fields[table_name] = {}
            self.changed_fields[table_name][column] = str(matches)
            logging.info(f"updated the changed fields\n changed_fields are {self.changed_fields}")
        except Exception as e:
            logging.error(f"error in assigning and updating the changed fields in regex function for : {column}")
            logging.error(e)
    return True

@register_method
def doReturn(self, parameters):
    """Returns the mentioned value
    'parameters':{
        'value_to_return':{"source":"input_config","table":"ocr","column":"Stock Date"}
    }
    """
    logging.info(f"parameters got are {parameters}")
    try:
        value_to_return = self.get_param_value(parameters['value_to_return'])
        return value_to_return
    except Exception as e:
        logging.error("cannot get value")
        logging.error(e)
        return ""

@register_method
def doRound(self, parameters):
    """Rounds a number to the required number of decimals
    'parameters' : {
        'value': {"source":"input_config","table":"ocr","column":""},
        'round_upto': {"source":"input_config","table":"ocr","column":""
    }
    """
    logging.info(f"parameters got are {parameters}")
    value = self.get_param_value(parameters['value'])
    round_upto = self.get_param_value(parameters['round_upto'])
    try:
        value = round(float(value), round_upto)
    except Exception as e :
        logging.error("ROUND FAILED SO RETURNING SAME VALUE")
        logging.error(e)
        value = value
    logging.info(f"Value after round is : {value}")
    return value

@register_method
def doMultiplyAmountFields(self, parameters):
    logging.info(f"parameters got are {parameters}")
    dict_data = self.get_param_value(parameters['dict_data'])
    group_name = self.get_param_value(parameters['group_name'])
    field_name = self.get_param_value(parameters['field'])
    print(dict_data)
    dict_data = json.loads(dict_data)
    print(type(dict_data))
    table  = parameters['table']
    try:
        logging.info(f'dict_data is : {dict_data}')
        stages_df = self.data_source[table]
        stages_df = pd.DataFrame(stages_df)
        for stage,value in dict_data.items():
            stages_list = list(stages_df.loc[stages_df[group_name] == stage][field_name])
            for field in stages_list:
                curr_value = self.data_source['ocr'][field]*value
                print(curr_value)
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                query_ocr = f"UPDATE `ocr` SET `{field}` = '{curr_value}' WHERE `case_id` = '{self.case_id}'"
                ocr_extracted = ocr_db.execute(query_ocr)
                
    except Exception as e:
        logging.error("Error In doMultiplyAmountFields function ")
        logging.error(e)
    
@register_method
def doUnitsCalculation(self, parameters) :
    """
    'parameters' : {
        'addontable_data': {'source':'input','value':''},
        'unit_unique_value' : {'source':'input','value':''},
        'field_unique_name':{},
        'operator':'',
        'key_name':'',
        'table':'',
        'column':''
    }
    """
    logging.info(f"parameters got are : {parameters}")
    addontable_data = self.get_param_value(parameters['addontable_data'])
    unit_unique_value = self.get_param_value(parameters['unit_unique_value'])
    field_unique_name = self.get_param_value(parameters['field_unique_name'])
    operator = parameters['operator']
    key_name = parameters['key_name']
    table_name = parameters['table']
    column_name = parameters['column']

    queue_db = DB('queues', tenant_id=self.tenant_id, **db_config)
    unit_query = f"SELECT `value` from `dropdown_definition` WHERE `unique_name`=%s and `dropdown_option` = %s"
    params = [field_unique_name,unit_unique_value]
    units_df = queue_db.execute_default_index(unit_query,params = params)
    logging.info(f"Got the units value from database is {units_df}")
    if not units_df.empty:
        unit_value = list(units_df['value'])[0]
        unit_value = str(unit_value).replace(",","")
    else:
        unit_value = 1
    logging.info(f"Units value to multiply is : {unit_value}")
    if addontable_data:
        row_data = addontable_data[0]['row_data']
        for row in row_data:
            row[key_name] = row[key_name].replace(",","")
            row[key_name] = eval(f"{row[key_name]} {operator} {unit_value}")

        addontable_data[0]['row_data'] = row_data
        logging.info(f"data getting inserted is : {row_data}")
        try:
            if table_name not in self.changed_fields:
                self.changed_fields[table_name] = {}
            self.changed_fields[table_name][column_name] = addontable_data
            logging.info(f"updated the changed fields\n changed_fields are {self.changed_fields}")
        except Exception as e:
            logging.error(f"error in assigning and updating the changed fields in regex function for : {column_name}")
            logging.error(e)
    return True

@register_method
def doUnitsCalculationColumn(self, parameters):
    """
    'parameters':{
        'table_name' :[],
        'column_names' : {} 
    }
    note: column_names are key value pairs of value and unit columns
    """
    logging.info(f"parameters got are : {parameters}")
    table_name = parameters['table_name']
    column_names = parameters['column_names']
    

    queue_db = DB('queues', tenant_id=self.tenant_id, **db_config)

    for data_column, unit_column in column_names.items():
        default_params = {
            'data_column' : {"source":"input_config","table":"ocr","column":str(data_column)},
            'unit_column': {"source":"input_config","table":"ocr","column":str(unit_column)}
        }
        data = self.get_param_value(default_params['data_column'])
        data = str(data).replace(",","")
        try:
            data =float(data)
        except:
            data = 0
        logging.info(f"Got the data is : {data}")
        units_unique_value = self.get_param_value(default_params['unit_column'])
        unit_query = f"SELECT `value` from `dropdown_definition` WHERE `unique_name`=%s and `dropdown_option` = %s"
        params = [unit_column,units_unique_value]
        logging.info(f"query is : {unit_query} where values are {params}")
        units_df = queue_db.execute_default_index(unit_query,params = params)
        logging.info(f"Got the units value from database for column {data_column} is {units_df}")
        if not units_df.empty:
            unit_value = list(units_df['value'])[0]
            unit_value = str(unit_value).replace(",","")
        else:
            unit_value = 1
        logging.info(f"Units value to multiply for column {data_column} is : {unit_value}")

        try:
            data = data * units_value
        except:
            data = eval(f"{data}*{unit_value}")

        self.data_source[table_name][data_column] = str(data)
        try:
            if table_name not in self.changed_fields:
                self.changed_fields[table_name] = {}
            self.changed_fields[table_name][data_column] = str(data)
            logging.info(f"updated the changed fields\n changed_fields are {self.changed_fields}")
        except Exception as e:
            logging.error(f"error in assigning and updating the changed fields in regex function for : {data_column}")
            logging.error(e)

    return True
######################################### INVESCO ##################################################
@register_method
def doDateTransform(self, parameters):
    """ Takes date as input and converts it into required format
        'parameters':{
            'input_date' : {"source":"input_config","table":"ocr","column":"Stock Date"},
            'output_format' : '%d-%b-%y'
            'output_type': {"source":"input","value":"object"}//can be object or string
        }
    """
    logging.info(f"parameters got are {parameters}")
    input_date = self.get_param_value(parameters['input_date'])
    input_date = str(input_date).replace(',',' ')
    output_format = parameters['output_format']
    try:
        output_type = self.get_param_value(parameters['output_type'])
    except:
        output_type = ""

    date_series = pd.Series(input_date)
    try:
        if output_type == "object":
            converted_date = pd.to_datetime(date_series,dayfirst=True,errors='coerce').dt.strftime(output_format)
            converted_date = datetime.strptime(converted_date[0],output_format).date()
            return converted_date
        else:
            converted_date = pd.to_datetime(date_series,dayfirst=True,errors='coerce').dt.strftime(output_format)
            return converted_date[0]
    except Exception as e:
        logging.error("cannot convert date to the given format")
        logging.error(e)
        return input_date

@register_method
def doPartialMatch(self, parameters):
    """ Returns highest matched string
    'parameters':{
        'words_table' : '',
        'words_column':'',
        'match_word' : {"source":"input_config","table":"ocr","column":"Stock Date"}
    }

    """
    logging.info(f"parameters got are {parameters}")
    words_table = parameters['words_table']
    words_column = parameters['words_column']
    match_word = self.get_param_value(parameters['match_word'])
    data = self.data_source[words_table]
    data = pd.DataFrame(data)
    words = list(data[words_column])
    logging.info(f"words got for checking match are : {words}")
    max_ratio = 0
    match_got = ""
    for word in words:
        try:
            ratio = SequenceMatcher(None,match_word.lower(),word.lower()).ratio() * 100
            if ratio > 75 and ratio > max_ratio:
                max_ratio = ratio
                match_got = word
                print(match_got)
        except Exception as e:
            logging.error("cannnot find match")
            logging.error(e)
 
    logging.info(f"match is {match_got} and ratio is {max_ratio}")
    return match_got
    

######################################### DELOITTE ##################################################
@register_method
def doContains_string(self,parameters):
    """ Returns true value if the string is present in the word
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
            cpt_check_rule = {'rule_type': 'static',
                'function': 'Contains',
                'parameters': { 'table_name': 'ocr','column_name': 'cpt_codes',
                                'value':{'source':'input', 'value':92610}
                        }
            }
    """
    logging.info(f"parameters got are {parameters}")
    word = self.get_param_value(parameters['word'])
    strings_list = parameters['strings_list']
    print(f'word is:',word)
    try:
        if str(word).strip() != "":
            for string in strings_list:
                if string.lower() in word.lower():
                    return True
            return False
    except Exception as e:
        return False
        print('==========> Error in doContains_string')
        print(e)

@register_method
def doAlnum_num_alpha(self,parameters):
    """ Returns true value if the string is Alpha or num or alnum
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
         {'rule_type':'static',
        'function': 'Alnum_num_alpha',
        'parameters' :{'word':{'source':'rule','value':get_range_rule1},
                       'option':'alpha',      
        }
        }
    """
    logging.info(f"parameters got are {parameters}")
    word = self.get_param_value(parameters['word'])
    option = parameters['option']
    try:
        if option == 'alpha':
            bool_value = word.isalpha()
            logging.info(f'{word} is alpha {bool_value}')
        if option == 'numeric':
            bool_value = word.isnumeric()
            logging.info(f'{word} is numeric {bool_value}')
        if option == 'alnum':
            bool_value = word.isalnum()
            logging.info(f'{word} is numeric {bool_value}')
        if option == 'is_numeric':
            try:
                bool_value = float(word).is_integer()
                logging.info(f'{word} is numeric {bool_value}')
            except:
                return False
        return bool_value
    except Exception as e:
        logging.error("Error In doAlnum_num_alpha function")
        logging.error(e)
        return False

@register_method
def doRegex(self,parameters):
    """ Returns a value by doing Regex on it
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        {'rule_type':'static',
        'function': 'Regex',
        'parameters' :{'phrase':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
                       'regex_str':"\d{6}",
        }
        }
    """
    logging.info ('I am in regexxxxxxxxxxxxxxxxxxxx')
    logging.info(f"parameters got are {parameters}")
    phrase = self.get_param_value(parameters['phrase'])
    regex_str = parameters['regex_str']
    reg_model = parameters['reg_model']
    try:
        if len(str(phrase)) > 1:
            logging.info(f'regex is : {regex_str}')
            logging.info(f'phrase is : {phrase}')
            regex= re.compile(f'{regex_str}')
            if reg_model == 'search':
                matches= re.search(regex, phrase)
                if matches:
                    matches = matches[0]
                else:
                    matches = ''
            if reg_model == 'match':
                matches= re.match(regex, phrase)
            if reg_model == 'findall':
                matches= re.findall(regex, phrase)
                if matches:
                    matches = matches[0]
                else:
                    matches = ''
            logging.info(f"Match got is {matches}")
            return matches
        else:
            return phrase
    except Exception as e:
        logging.error("Error In doRegex function")
        logging.error(e)
        return phrase

@register_method
def doZfill(self,parameters):
    """ Returns a value by doing Regex on it
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        {'rule_type':'static',
        'function': 'Regex',
        'parameters' :{'value':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
                       'zfill_no':2,      
        }
        }
    """
    logging.info(f"parameters got are {parameters}")
    value = self.get_param_value(parameters['value'])
    Zfill_no = parameters['zfill_no']
    try:
        logging.info(f'value is : {value}')
        logging.info(f'Zfill_no is : {Zfill_no}')
        value = str(value).zfill(Zfill_no)
        return value
    except Exception as e:
        logging.error("Error In doZfill function")
        logging.error(e)
        return value
'''
@register_method
def doLTDandTDScalc(self,parameters):
    logging.info(f"parameters got are {parameters}")
    Assessable_Value = self.get_param_value(parameters['Assessable_Value'])
    previous_assessable_value = self.get_param_value(parameters['previous_assessable_value'])
    client_name = self.get_param_value(parameters['client_name'])
    client_id = self.get_param_value(parameters['client_id'])
    ven_name = self.get_param_value(parameters['ven_name'])
    if ven_name == "":
        ven_name = self.get_param_value(parameters['vendor_name'])
    in_date = self.get_param_value(parameters['in_date'])
    tds_rate = self.get_param_value(parameters['tds_rate'])
    tds_section = self.get_param_value(parameters['tds_section'])
    ltd_status = self.get_param_value(parameters['ltd_status'])
    standard_format = self.get_param_value(parameters['standard_format'])
    logging.info(f"========>{Assessable_Value},{client_name},{client_id},{ven_name},{in_date},{tds_rate},{tds_section}")
    try:
        print(f"tds_rate is",tds_rate)
        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        tds_query = f"UPDATE `ocr` SET `tds_rate` = {tds_rate}  WHERE `case_id` = '{self.case_id}'"
        logging.info(f"assigning for tds_rate query is {tds_query}")
        df_tds = ocr_db.execute_(tds_query)

        logging.info(f"assigning for tds_section {tds_section}")
        tds_sec_query = f"UPDATE `ocr` SET `tds_section/rule` = '{tds_section}'  WHERE `case_id` = '{self.case_id}'"
        df_tds_sec = ocr_db.execute_(tds_sec_query)
        logging.info(f"assigning section query is {tds_section}")

        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        get_report = f"SELECT * FROM `ltd_master` WHERE `start_date` <= '{in_date}' AND `end_date` >= '{in_date}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
        logging.info(f"query is {get_report}")
        df = ocr_db.execute_(get_report)
        print(df)
        if len(df) != 0:
            parsed_date1 = parse(str(df['end_date'][0]), fuzzy=True, dayfirst=True).strftime(standard_format)
            logging.info(f"end date after date parse is {parsed_date1}") 
            parsed_date2 = parse(str(df['start_date'][0]), fuzzy=True, dayfirst=True).strftime(standard_format)
            logging.info(f"start date after date parse is {parsed_date2}") 
            ltd_ocr_update_query = f"UPDATE `ocr` SET `ltd_end_date` = '{parsed_date1}', `ltd_start_date` = '{parsed_date2}' WHERE `case_id` = '{self.case_id}'"
            logging.info(f"ltd_ocr_update_query is {ltd_ocr_update_query}")
            ocr_db.execute_(ltd_ocr_update_query)
            stacked_amount = (float(str(df['stacked_amount'][0]).replace(',',''))) + (float(str(Assessable_Value).replace(',','')))
            
            
            if float(str(stacked_amount).replace(',','')) <= float(str(df['ltd_limit'][0]).replace(',','')) :
                logging.info(f"ltd_limit before subtract is {df['ltd_limit'][0]}")
                if ltd_status == 0 :
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    set_stack = f"UPDATE `ltd_master` SET `stacked_amount` = '{stacked_amount}' WHERE `start_date` <= '{in_date}' AND `end_date` >= '{in_date}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
                    logging.info(f'ltd_stack query is : {set_stack}')
                    ocr_db.execute_(set_stack)


                    ltd_limit = (float(str(df['ltd_limit'][0]).replace(',',''))) - (float(str(df['stacked_amount'][0]).replace(',','')))
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    ltd_decrement_query = f"UPDATE `ocr` SET `ltd_limit` = '{ltd_limit}' WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_limit decrement query is : {ltd_decrement_query}')
                    ocr_db.execute_(ltd_decrement_query)
                elif (float(str(Assessable_Value).replace(',','')) != float(str(previous_assessable_value).replace(',',''))) and (ltd_status == 1) :
                     
                    logging.info(f'aaaaaaaaaaaaaaaaaaa is {stacked_amount}')
                    stacked_amount = (float(str(stacked_amount).replace(',',''))) - (float(str(previous_assessable_value).replace(',','')))
                    
                    #df['stacked_amount'][0] = stacked_amount
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    set_stack = f"UPDATE `ltd_master` SET `stacked_amount` = '{stacked_amount}' WHERE `start_date` <= '{in_date}' AND `end_date` >= '{in_date}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
                    logging.info(f'ltd_stack query is : {set_stack}')
                    ocr_db.execute_(set_stack)                    
                    logging.info(f"previous_assessable_value is {previous_assessable_value}")
                    
                    logging.info(f",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, {Assessable_Value}")         
                    ltd_limit = ltd_limit = (float(str(df['ltd_limit'][0]).replace(',',''))) - (float(str(df['stacked_amount'][0]).replace(',','')))
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    ltd_decrement_query = f"UPDATE `ocr` SET `ltd_limit` = '{ltd_limit}' WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_limit decrement query is : {ltd_decrement_query}')
                    ocr_db.execute_(ltd_decrement_query)

                ltd_rate = (df['ltd_rate'][0])
                ltd_amount = float(str(Assessable_Value).replace(',',''))*float(ltd_rate)/100
                logging.info(f'ltd_amount is : {ltd_amount}')
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                set_ltd = f"UPDATE `ocr` SET `ltd_amount` = '{ltd_amount}', `ltd_rate` = '{ltd_rate}'  WHERE `case_id` = '{self.case_id}'"
                logging.info(f'ltd_amount query is : {set_ltd}')
                df = ocr_db.execute_(set_ltd)
                ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'Yes', `ltd_status` = 1  WHERE `case_id` = '{self.case_id}'"
                ltd_app = ocr_db.execute_(ltd_app)
                previous_query = f"UPDATE `ocr` SET `previous_assessable_value` = '{Assessable_Value}'  WHERE `case_id` = '{self.case_id}'"
                df = ocr_db.execute_(previous_query)
                logging.info(f"previous_assessable_value is {Assessable_Value}")
                return True
            elif (float(str(Assessable_Value).replace(',','')) != float(str(previous_assessable_value).replace(',',''))) and ltd_status == 1 :
                logging.info(f"previous_assessable_value is {previous_assessable_value}")
                
                stacked_amount = (float(str(df['stacked_amount'][0]).replace(',',''))) - (float(str(previous_assessable_value).replace(',','')))
                
                #df['stacked_amount'][0] = stacked_amount
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                set_stack = f"UPDATE `ltd_master` SET `stacked_amount` = '{stacked_amount}' WHERE `start_date` <= '{in_date}' AND `end_date` >= '{in_date}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
                logging.info(f'ltd_stack query is : {set_stack}')
                ocr_db.execute_(set_stack)

                if float(str(stacked_amount).replace(',','')) <= float(str(ltd_limit).replace(',','')) :
                    logging.info(f"ltd_limit before subtract is {ltd_limit}") 
                    logging.info(f",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, {Assessable_Value}")         
                    ltd_limit = df['ltd_limit'][0] 
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    ltd_decrement_query = f"UPDATE `ocr` SET `ltd_limit` = '{ltd_limit}' WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_limit decrement query is : {ltd_decrement_query}')
                    ocr_db.execute_(ltd_decrement_query)
                    
                    ltd_rate = ltd_limit = (float(str(df['ltd_limit'][0]).replace(',',''))) - (float(str(df['stacked_amount'][0]).replace(',','')))
                    ltd_amount = float(str(Assessable_Value).replace(',',''))*float(ltd_rate)/100
                    logging.info(f'ltd_amount is : {ltd_amount}')
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    set_ltd = f"UPDATE `ocr` SET `ltd_amount` = '{ltd_amount}', `ltd_rate` = '{ltd_rate}'  WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_amount query is : {set_ltd}')
                    df = ocr_db.execute_(set_ltd)
                    ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'Yes', `ltd_status` = 1  WHERE `case_id` = '{self.case_id}'"
                    ltd_app = ocr_db.execute_(ltd_app)
                    previous_query = f"UPDATE `ocr` SET `previous_assessable_value` = '{Assessable_Value}'  WHERE `case_id` = '{self.case_id}'"
                    df = ocr_db.execute_(previous_query)
                    logging.info(f"previous_assessable_value is {Assessable_Value}")
                    return True
            else:
                tds_amount = float(str(Assessable_Value).replace(',',''))*float(tds_rate)/100
                logging.info(f'tds_amount is : {tds_amount}')
                print(f'tds_amount is : ',tds_amount)
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                set_tds = f"UPDATE `ocr` SET `tds_amount` = '{tds_amount}'  WHERE `case_id` = '{self.case_id}'"
                logging.info(f'tds_amount query is : {set_tds}')
                df = ocr_db.execute_(set_tds)
                ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'No'  WHERE `case_id` = '{self.case_id}'"
                ltd_app = ocr_db.execute_(ltd_app)
                return True
        else:
            logging.info("len(df) == 0 so came to tds_amount")
            tds_amount = float(str(Assessable_Value).replace(',',''))*float(tds_rate)/100
            logging.info(f'tds_amount is : {tds_amount}')
            print(f'tds_amount is : ',tds_amount)
            ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            set_tds = f"UPDATE `ocr` SET `tds_amount` = '{tds_amount}'  WHERE `case_id` = '{self.case_id}'"
            logging.info(f'tds_amount query is : {set_tds}')      
            df = ocr_db.execute_(set_tds)
            ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'No'  WHERE `case_id` = '{self.case_id}'"
            ltd_app = ocr_db.execute_(ltd_app)
            return True
        return False
    except Exception as e:
        logging.error(f"Error In ltd_tds function")
        logging.error(e)
'''

@register_method
def doLTDandTDScalc(self,parameters):
    logging.info(f"parameters got are {parameters}")
    Assessable_Value = self.get_param_value(parameters['Assessable_Value'])
    previous_assessable_value = self.get_param_value(parameters['previous_assessable_value'])
    client_name = self.get_param_value(parameters['client_name'])
    client_id = self.get_param_value(parameters['client_id'])
    ven_name = self.get_param_value(parameters['ven_name'])
    if ven_name == "":
        ven_name = self.get_param_value(parameters['vendor_name'])
    in_date = self.get_param_value(parameters['in_date'])
    tds_rate = self.get_param_value(parameters['tds_rate'])
    tds_section = self.get_param_value(parameters['tds_section'])
    ltd_status = self.get_param_value(parameters['ltd_status'])
    standard_format = self.get_param_value(parameters['standard_format'])
    logging.info(f"========>{Assessable_Value},{client_name},{client_id},{ven_name},{in_date},{tds_rate},{tds_section}")
    try:
        print(f"tds_rate is",tds_rate)
        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        tds_query = f"UPDATE `ocr` SET `tds_rate` = {tds_rate}  WHERE `case_id` = '{self.case_id}'"
        logging.info(f"assigning for tds_rate query is {tds_query}")
        df_tds = ocr_db.execute_(tds_query)

        logging.info(f"assigning for tds_section {tds_section}")
        tds_sec_query = f"UPDATE `ocr` SET `tds_section/rule` = '{tds_section}'  WHERE `case_id` = '{self.case_id}'"
        df_tds_sec = ocr_db.execute_(tds_sec_query)
        logging.info(f"assigning section query is {tds_section}")

        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        get_report = f"SELECT * FROM `ltd_master` WHERE `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
        logging.info(f"query is {get_report}")
        df = ocr_db.execute_(get_report)
        print(df)
        if len(df) != 0:
            date_of_issue=df['date_of_issue'][0]
            #date_of_issue = '21.1.2020 '
            output_format = '%y-%m-%d %H:%M:%S'
            date_series = pd.Series(date_of_issue)
            date_of_issue = pd.to_datetime(date_series,dayfirst=True,errors='coerce').dt.strftime(output_format)
            date_of_issue = datetime.strptime(date_of_issue[0],output_format)
            
            
            logging.info(f'date type is {type(date_of_issue)} and date is {date_of_issue}')
            #my_date = datetime.strptime(date_of_issue, "%m-%d-%Y")

            #logging.info(f'my_date is:{my_date}')
            #logging.info(f'Type: ,{type(my_date)}')
            logging.info('at df end date and df start date')
            #df['end_date'] = df['end_date'] . dt. strftime('%y-%m-%d %H:%M:%S')#pd.to_datetime(df['end_date'], format='yyyy/mm/dd HH:mm:ss')
            #df['start_date'] = df['start_date'] . dt. strftime('%y-%m-%d %H:%M:%S')#pd.to_datetime(df['start_date'], format='yyyy/mm/dd HH:mm:ss')
            dfstart_date = df['start_date'][0] 
            #dfstart_date = '21.03.2020 00:00:00.0000000'
            output_format = '%y-%m-%d %H:%M:%S'
            date_series = pd.Series(dfstart_date)
            dfstart_date = pd.to_datetime(date_series,dayfirst=True,errors='coerce').dt.strftime(output_format)
            dfstart_date = datetime.strptime(dfstart_date[0],output_format)
            logging.info(f'start date is:{dfstart_date}')
            dfend_date = df['end_date'][0]
            #dfend_date = '21.05.2020 '
            output_format = '%y-%m-%d %H:%M:%S'
            date_series = pd.Series(dfend_date)
            dfend_date = pd.to_datetime(date_series,dayfirst=True,errors='coerce').dt.strftime(output_format)
            dfend_date = datetime.strptime(dfend_date[0],output_format)
            logging.info(f'{dfend_date}')
            dfid = df['id'][0]
            logging.info(f'~~~~~~~~~~~~~~~~~ {dfstart_date},{dfend_date},{dfid}')
        if len(df) != 0 and dfstart_date <= in_date and  dfend_date >= in_date:
            parsed_date1 = parse(str(df['end_date'][0]), fuzzy=True, dayfirst=True).strftime(standard_format)
            logging.info(f"end date after date parse is {parsed_date1}") 
            parsed_date2 = parse(str(df['start_date'][0]), fuzzy=True, dayfirst=True).strftime(standard_format)
            logging.info(f"start date after date parse is {parsed_date2}") 
            ltd_ocr_update_query = f"UPDATE `ocr` SET `ltd_end_date` = '{parsed_date1}', `ltd_start_date` = '{parsed_date2}' WHERE `case_id` = '{self.case_id}'"
            logging.info(f"ltd_ocr_update_query is {ltd_ocr_update_query}")
            ocr_db.execute_(ltd_ocr_update_query)
            stacked_amount = (float(str(df['stacked_amount'][0]).replace(',',''))) + (float(str(Assessable_Value).replace(',','')))
            
            
            if float(str(stacked_amount).replace(',','')) <= float(str(df['ltd_limit'][0]).replace(',','')) :
                logging.info(f"ltd_limit before subtract is {df['ltd_limit'][0]}")
                if ltd_status == 0 :
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    set_stack = f"UPDATE `ltd_master` SET `stacked_amount` = '{stacked_amount}' WHERE `id` = '{dfid}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
                    logging.info(f'ltd_stack query is : {set_stack}')
                    ocr_db.execute_(set_stack)


                    ltd_limit = (float(str(df['ltd_limit'][0]).replace(',',''))) - (float(str(df['stacked_amount'][0]).replace(',','')))
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    ltd_decrement_query = f"UPDATE `ocr` SET `ltd_limit` = '{ltd_limit}' WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_limit decrement query is : {ltd_decrement_query}')
                    ocr_db.execute_(ltd_decrement_query)
                elif (float(str(Assessable_Value).replace(',','')) != float(str(previous_assessable_value).replace(',',''))) and (ltd_status == 1) :
                     
                    logging.info(f'aaaaaaaaaaaaaaaaaaa is {stacked_amount}')
                    stacked_amount = (float(str(stacked_amount).replace(',',''))) - (float(str(previous_assessable_value).replace(',','')))
                    
                    #df['stacked_amount'][0] = stacked_amount
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    set_stack = f"UPDATE `ltd_master` SET `stacked_amount` = '{stacked_amount}' WHERE `id` = '{dfid}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
                    logging.info(f'ltd_stack query is : {set_stack}')
                    ocr_db.execute_(set_stack)                    
                    logging.info(f"previous_assessable_value is {previous_assessable_value}")
                    
                    logging.info(f",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, {Assessable_Value}")         
                    ltd_limit = (float(str(df['ltd_limit'][0]).replace(',',''))) - (float(str(df['stacked_amount'][0]).replace(',','')))
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    ltd_decrement_query = f"UPDATE `ocr` SET `ltd_limit` = '{ltd_limit}' WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_limit decrement query is : {ltd_decrement_query}')
                    ocr_db.execute_(ltd_decrement_query)

                ltd_rate = (df['ltd_rate'][0])
                ltd_amount = float(str(Assessable_Value).replace(',',''))*float(ltd_rate)/100
                logging.info(f'ltd_amount is : {ltd_amount}')
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                set_ltd = f"UPDATE `ocr` SET `ltd_amount` = '{ltd_amount}', `ltd_rate` = '{ltd_rate}'  WHERE `case_id` = '{self.case_id}'"
                logging.info(f'ltd_amount query is : {set_ltd}')
                df = ocr_db.execute_(set_ltd)
                ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'Yes', `ltd_status` = 1  WHERE `case_id` = '{self.case_id}'"
                ltd_app = ocr_db.execute_(ltd_app)
                previous_query = f"UPDATE `ocr` SET `previous_assessable_value` = '{Assessable_Value}'  WHERE `case_id` = '{self.case_id}'"
                df = ocr_db.execute_(previous_query)
                logging.info(f"previous_assessable_value is {Assessable_Value}")
                return True
            elif (float(str(Assessable_Value).replace(',','')) != float(str(previous_assessable_value).replace(',',''))) and ltd_status == 1 :
                logging.info(f"previous_assessable_value is {previous_assessable_value}")
                
                stacked_amount = (float(str(df['stacked_amount'][0]).replace(',',''))) - (float(str(previous_assessable_value).replace(',','')))
                
                #df['stacked_amount'][0] = stacked_amount
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                set_stack = f"UPDATE `ltd_master` SET `stacked_amount` = '{stacked_amount}' WHERE `id` = '{dfid}' AND `vendor_name` LIKE '%{ven_name}%' AND `client_id` = '{client_id}'"
                logging.info(f'ltd_stack query is : {set_stack}')
                ocr_db.execute_(set_stack)

                if float(str(stacked_amount).replace(',','')) <= float(str(ltd_limit).replace(',','')) :
                    logging.info(f"ltd_limit before subtract is {ltd_limit}") 
                    logging.info(f",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, {Assessable_Value}")         
                    ltd_limit = df['ltd_limit'][0] 
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    ltd_decrement_query = f"UPDATE `ocr` SET `ltd_limit` = '{ltd_limit}' WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_limit decrement query is : {ltd_decrement_query}')
                    ocr_db.execute_(ltd_decrement_query)
                    
                    ltd_rate = ltd_limit = (float(str(df['ltd_limit'][0]).replace(',',''))) - (float(str(df['stacked_amount'][0]).replace(',','')))
                    ltd_amount = float(str(Assessable_Value).replace(',',''))*float(ltd_rate)/100
                    logging.info(f'ltd_amount is : {ltd_amount}')
                    ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                    set_ltd = f"UPDATE `ocr` SET `ltd_amount` = '{ltd_amount}', `ltd_rate` = '{ltd_rate}'  WHERE `case_id` = '{self.case_id}'"
                    logging.info(f'ltd_amount query is : {set_ltd}')
                    df = ocr_db.execute_(set_ltd)
                    ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'Yes', `ltd_status` = 1  WHERE `case_id` = '{self.case_id}'"
                    ltd_app = ocr_db.execute_(ltd_app)
                    previous_query = f"UPDATE `ocr` SET `previous_assessable_value` = '{Assessable_Value}'  WHERE `case_id` = '{self.case_id}'"
                    df = ocr_db.execute_(previous_query)
                    logging.info(f"previous_assessable_value is {Assessable_Value}")
                    return True
            else:
                tds_amount = float(str(Assessable_Value).replace(',',''))*float(tds_rate)/100
                logging.info(f'tds_amount is : {tds_amount}')
                print(f'tds_amount is : ',tds_amount)
                ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
                set_tds = f"UPDATE `ocr` SET `tds_amount` = '{tds_amount}'  WHERE `case_id` = '{self.case_id}'"
                logging.info(f'tds_amount query is : {set_tds}')
                df = ocr_db.execute_(set_tds)
                ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'No'  WHERE `case_id` = '{self.case_id}'"
                ltd_app = ocr_db.execute_(ltd_app)
                return True
        else:
            logging.info("len(df) == 0 so came to tds_amount")
            tds_amount = float(str(Assessable_Value).replace(',',''))*float(tds_rate)/100
            logging.info(f'tds_amount is : {tds_amount}')
            print(f'tds_amount is : ',tds_amount)
            ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            set_tds = f"UPDATE `ocr` SET `tds_amount` = '{tds_amount}'  WHERE `case_id` = '{self.case_id}'"
            logging.info(f'tds_amount query is : {set_tds}')      
            df = ocr_db.execute_(set_tds)
            ltd_app = f"UPDATE `ocr` SET `ltd_applicability` = 'No'  WHERE `case_id` = '{self.case_id}'"
            ltd_app = ocr_db.execute_(ltd_app)
            return True
        return False
    except Exception as e:
        logging.error(f"Error In ltd_tds function")
        logging.error(e)
#'''
@register_method
def AmountCompare(self,parameters):
    left_param, operator, right_param = parameters['left_param'], parameters['operator'], parameters['right_param'] 
    left_param_value, right_param_value = self.get_param_value(left_param), self.get_param_value(right_param)
    logging.debug(f"left param value is {left_param_value} and type is {type(left_param_value)}")
    logging.debug(f"right param value is {right_param_value} and type is {type(right_param_value)}")
    logging.debug(f"operator is {operator}")
    try:
        left_param_value = str(left_param_value).replace(',','').replace('INR','').replace('RUPEES','').replace('inr','').replace('rupees','').replace('rupee','').replace('RUPEE','').replace(' ','').replace(':','')
        right_param_value = str(right_param_value).replace(',','').replace('INR','').replace('RUPEES','').replace('inr','').replace('rupees','').replace('rupee','').replace('RUPEE','').replace(' ','').replace(':','')
        if operator == ">=":
            print(float(left_param_value) >= float(right_param_value))
            return (float(left_param_value) >= float(right_param_value))
        if operator == "<=":
            print(float(left_param_value) <= float(right_param_value))
            return (float(left_param_value) <= float(right_param_value))
        if operator == ">":
            print(float(left_param_value) > float(right_param_value))
            return (float(left_param_value) > float(right_param_value))
        if operator == "<":
            print(float(left_param_value) < float(right_param_value))
            return (float(left_param_value) < float(right_param_value))
        if operator == "==":
            print(float(left_param_value) == float(right_param_value))
            return (float(left_param_value) == float(right_param_value))
    except Exception as e:
        logging.debug(f"error in compare key value {left_param_value} {operator} {right_param_value}")
        logging.debug(str(e))
        return False
'''    
@register_method
def duplicatecase(self,parameters):
    logging.info(f"parameters got are {parameters}")
    try:
        invoice_number = self.get_param_value(parameters['invoice_number'])
        #client_name = self.get_param_value(parameters['client_name'])
        #vendor_name = self.get_param_value(parameters['vendor_name'])
        invoice_date = self.get_param_value(parameters['invoice_date'])
        total_value = self.get_param_value(parameters['total_value'])
    except Exception as e:
        logging.error("Error In duplicate function")
        logging.error(e)
    try:
        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        dup_query = f"SELECT * FROM `ocr` WHERE `invoice_number` = '{invoice_number}' AND `invoice_date` = '{invoice_date}' AND `total_value` = '{total_value}' and `duplicate` = 0 and `case_id` != '{self.case_id}'"
        df = ocr_db.execute_(dup_query)
        print(dup_query)
        print("length of df is:",len(df))
        if len(df) >= 1 :
            orig_case_id = df['case_id'][0]
            dup_delete_query = f"SELECT * FROM `process_queue` WHERE `case_id` = '{orig_case_id}'"
            process_queue_db = DB('queues', tenant_id=self.tenant_id, **db_config)
            df = process_queue_db.execute_(dup_delete_query)
            print(dup_delete_query)
            print("length of df is:",len(df))
            if df['queue'][0] != 'delete' :
                comment = f"Case moved to rejection due to duplicate file. The case id for the original case is {orig_case_id}"
                comment_query = f"Update `ocr` set `rejection_comment` = '{comment}', `duplicate` = 1 where `case_id` = '{self.case_id}'"
                # update_query = f"UPDATE `ocr` set `duplicate` = 1 where `case_id` = '{self.case_id}'"
                # ocr_db.execute_(update_query)
                ocr_db.execute_(comment_query)
                return True
        else:
            update_query = f"UPDATE `ocr` set `duplicate` = 0 where `case_id` = '{self.case_id}'"
            ocr_db.execute_(update_query)
            return False
    except Exception as e:
        logging.error("Error In duplicate function")
        logging.error(e)
        return False
'''
@register_method
def duplicatecase(self,parameters):
    logging.info(f"parameters got are {parameters}")
    try:
        invoice_number = self.get_param_value(parameters['invoice_number'])
        #client_name = self.get_param_value(parameters['client_name'])
        #vendor_name = self.get_param_value(parameters['vendor_name'])
        invoice_date = self.get_param_value(parameters['invoice_date'])
        #total_value = self.get_param_value(parameters['total_value'])
    except Exception as e:
        logging.error("Error In duplicate function")
        logging.error(e)
    try:
        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        dup_query = f"SELECT * FROM `ocr` WHERE `invoice_number` = '{invoice_number}' AND `invoice_date` = '{invoice_date}' AND `duplicate` = 0 and `case_id` != '{self.case_id}'"
        df = ocr_db.execute_(dup_query)
        print(dup_query)
        print("length of df is:",len(df))
        if len(df) == 1 :
            orig_case_id = df['case_id'][0]
            dup_delete_query = f"SELECT * FROM `process_queue` WHERE `case_id` = '{orig_case_id}'"
            process_queue_db = DB('queues', tenant_id=self.tenant_id, **db_config)
            df = process_queue_db.execute_(dup_delete_query)
            print(dup_delete_query)
            print("length of df is:",len(df))
            
            if df['queue'][0] != 'delete' :
                comment = f"Case moved to rejection due to duplicate file. The case id for the original case is {orig_case_id}"
                comment_query = f"Update `ocr` set `rejection_comment` = '{comment}', `duplicate` = 1 where `case_id` = '{self.case_id}'"
                # update_query = f"UPDATE `ocr` set `duplicate` = 1 where `case_id` = '{self.case_id}'"
                # ocr_db.execute_(update_query)
                ocr_db.execute_(comment_query)
                return True
        elif len(df) > 1:
            for each in df['case_id']:
                logging.info(f'got each case id as: {each}')
                dup_delete_query = f"SELECT * FROM `process_queue` WHERE `case_id` = '{each}'"
                process_queue_db = DB('queues', tenant_id=self.tenant_id, **db_config)
                df = process_queue_db.execute_(dup_delete_query)
                print(dup_delete_query)
                print("length of df is:",len(df))
                
                if  len(df) == 1 and df['queue'][0] != 'delete' :
                    comment = f"Case moved to rejection due to duplicate file. The case id for the original case is {each}"
                    comment_query = f"Update `ocr` set `rejection_comment` = '{comment}', `duplicate` = 1 where `case_id` = '{self.case_id}'"
                    # update_query = f"UPDATE `ocr` set `duplicate` = 1 where `case_id` = '{self.case_id}'"
                    # ocr_db.execute_(update_query)
                    ocr_db.execute_(comment_query)
                    return True 
                               
        else:
            update_query = f"UPDATE `ocr` set `duplicate` = 0 where `case_id` = '{self.case_id}'"
            ocr_db.execute_(update_query)
            return False
    except Exception as e:
        logging.error("Error In duplicate function")
        logging.error(e)
        return False



@register_method
def doAppendDB(self,parameters):
    logging.info(f"parameters got are {parameters}")
    try:
        assign_table = parameters['assign_table']
        assign_value = self.get_param_value(parameters['assign_value'])
        table_key = assign_table['table']
        column_key = assign_table['column']
    except Exception as e:
        logging.error("Error In doAppend function")
        logging.error(e)
    try:
        ocr_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
        concat_query = f"UPDATE `{table_key}` SET `{column_key}` = CONCAT(`{column_key}`,'{assign_value}' + CHAR(13) + CHAR(13)) WHERE `case_id` = '{self.case_id}'"
        df = ocr_db.execute_(concat_query)
        print(concat_query)
        return True
    except Exception as e:
        logging.error("Error In doAppend function")
        logging.error(e)
        return False

@register_method
def doPartialCompare(self, parameters):
    """ Returns highest matched string
    'parameters':{
        'words_table' : '',
        'words_column':'',
        'match_word' : {"source":"input_config","table":"ocr","column":"Stock Date"}
    }

    """
    logging.info(f"parameters got are {parameters}")
    match_word = self.get_param_value(parameters['match_word'])
    word = self.get_param_value(parameters['word'])
    print(match_word)
    print(word)
    max_ratio = 0
    match_got = ""
    try:
        ratio = SequenceMatcher(None,match_word.lower(),word.lower()).ratio() * 100
        if ratio > 75 and ratio > max_ratio:
            max_ratio = ratio
            match_got = word
            print(match_got)
            logging.info(f"match is {match_got} and ratio is {max_ratio}")
            return True
        else:
            return False
    except Exception as e:
        logging.error("cannnot find match")
        logging.error(e)

    logging.info(f"match is {match_got} and ratio is {max_ratio}")
    return match_got

@register_method
def doGetColumnValue(self, parameters):
    """ Returns value of the column name that got in master table based on filters
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        'parameters' :{
            'get_column_name':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'from_table':{'source':'input', 'value':'x'},
            'lookup_filters': [{
                    'column_name': 'Vendor GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
                {
                    'column_name': 'DRL GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                }]
        }
    """
    logging.info(f"parameters got are {parameters}")
    column_name_to_select = self.get_param_value(parameters['get_column_name'])
    from_table = self.get_param_value(parameters['from_table'])
    lookup_filters = parameters['lookup_filters']

    try:
        master_data = self.data_source[from_table]
    except Exception as e:
        logging.error(f"data source does not have the table {from_table}")
        logging.error(e)
        master_data = {}

    master_df = pd.DataFrame(master_data) 

    # build the query
    query = ""
    for lookup in lookup_filters:
        lookup_column = lookup['column_name']
        compare_value = self.get_param_value(lookup['compare_with'])
        query += f"{lookup_column} == '{compare_value}' & "
    query = query.strip(' & ') # the final strip for the extra &
    result_df = master_df.query(query)
    result_df = result_df.reset_index(drop=True)

    # get the wanted column from the dataframe
    if not result_df.empty:
        try:
            logging.debug(f"got data is {result_df[column_name_to_select][0]}")
            return result_df[column_name_to_select][0] # just return the first value of the matches
        except Exception as e:
            logging.error(f"error in selecting the required data from the result")
            logging.error(e)
            return ""

@register_method
def dogetusername(self,paramaters):
    '''Returns name of the user
        'parameters' :{}
    '''
    try:
        user_name = self.user
        logging.info(f'user name is : {user_name}')
    except Exception as e:
        logging.error("user_name function failed")
        logging.error(e)
        user_name = ""
    return user_name

@register_method
def doGetDateTime(self, parameters):
    """ Returns present date and time
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        {'rule_type':'static',
        'function': 'GetDateTime',
        'parameters' :{
        }
        }
    """
    logging.info(f"parameters got are {parameters}")
    try:
        date_time = datetime.now()
        #date_time=date_time.strftime("%d-%m-%Y %H:%M %p")
        logging.info(f"Got dateand time are : {date_time}")
    except:
        logging.error("date time function failed")
        date_time = ""
    
    return date_time




@register_method
def doDelete(self, parameters):
    """Returns value of the column name that got in ocr as value
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        'parameters' :{
            'from_table':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'}
        }
    """
    logging.info(f"parameters got are {parameters}")
    try:
        self.rule_params = {}
        self.trace_exec = []
    except Exception as e:
        logging.error(f"Deleting from the data failed")
        logging.error(e)
    return True

@register_method
def doDateCheck(self, parameters):
    """
    Returns true or false on base of given dates validation
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        'parameters' :{
            'invoice_date':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'check_date':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'input_date':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'}
        }
    """
    logging.info(f"parameters got are {parameters}")
    invoice_date = self.get_param_value(parameters['invoice_date'])
    check_date = self.get_param_value(parameters['check_date'])
    input_date = self.get_param_value(parameters['input_date'])
    try:
        check_date = parse(check_date).date()
        logging.info(f"check date after conversion is : {check_date}")
        invoice_date = parse(invoice_date).date()
        logging.info(f"invoice date conversion is : {invoice_date}")
        invoice_date = invoice_date+relativedelta(months=+1)
        invoice_date = invoice_date.replace(day=int(input_date))
        logging.info(f"invoice date after conversion is : {invoice_date}")
    except Exception as e:
        logging.error("Date conversions failed")
        logging.error(e)

    if invoice_date >= check_date:
        return True
    else:
        return False

@register_method
def doTablesCompare(self, parameters):
    """ Works on inner tables present inside a column
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        'parameters' :{
            'super_table':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'sub_table':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'super_filter_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'super_compare_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'sub_compare_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'name_column_ref':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'name_diff_assign_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'status_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'}
        }
    """
    logging.info(f"parameters got are {parameters}")
    super_table = self.get_param_value(parameters['super_table'])
    sub_table = self.get_param_value(parameters['sub_table'])
    super_filter_column = self.get_param_value(parameters['super_filter_column'])
    sub_filter_column = self.get_param_value(parameters['sub_filter_column'])
    super_compare_column = self.get_param_value(parameters['super_compare_column'])
    sub_compare_column = self.get_param_value(parameters['sub_compare_column'])
    name_column_ref = self.get_param_value(parameters['name_column_ref'])
    name_diff_assign_column = self.get_param_value(parameters['name_diff_assign_column'])
    status_column = self.get_param_value(parameters['status_column'])

    try:
        super_col = [values[0] for values in super_table[0]]
        super_df = pd.DataFrame(columns = super_col)
        for ind in range(1,len(super_table)):
            row_ = [row_value[0] for row_value in super_table[ind]]
            super_df.loc[ind] = row_
        logging.info(f"Got the super table is : {super_df}")
    except Exception as e:
        logging.error("Failed in convering Super table to data frame")
        logging.error(e)

    try:
        sub_col = [values[0] for values in sub_table[0]]
        sub_df = pd.DataFrame(columns = sub_col)
        for ind in range(1,len(sub_table)):
            row_ = [row_value[0] for row_value in sub_table[ind]]
            sub_df.loc[ind] = row_
        logging.info(f"Got the super table is : {sub_df}")
    except Exception as e:
        logging.error("Failed in convering Sub table to data frame")
        logging.error(e)

    status_str = ""
    name_diff_amount_str = ""
    for sub_ind in sub_df.index:
        for super_ind in super_df.index:
            if sub_df[sub_filter_column][sub_ind] == super_df[super_filter_column][super_ind]:
                if sub_df[sub_compare_column] <= super_df[super_compare_column]:
                    status_str = status_str + "Complied"
                else:
                    status_str = status_str + "Non-Complied"
                name_diff_amount_str = name_diff_amount_str + f"{sub_df[name_column_ref]},{ float(sub_df[sub_compare_column]) - float(super_df[super_compare_column])}\n"
    logging.info(f"Got the compiled status is : {status_str}")
    logging.info(f"Got final name and amount differencestring is : {name_diff_amount_str}")
    extraction_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
    ocr_update_query = f'UPDATE `ocr` SET `{status_column}` = CONCAT(`{status_column}`,"\\n{status_str}\\n"), `{name_diff_assign_column}` = CONCAT(`{name_diff_assign_column}`,"\\n{name_diff_amount_str}\\n") WHERE `case_id` = "{self.case_id}"'
    df = extraction_db.execute_(ocr_update_query)
    if("Non-Complied" in status_str):
        return False
    else:
        return True
@register_method
def doSelectCustom(self, parameters):
    """Returns the vlookup value from the tables.
    Args:
        parameters (dict): The table from which we have to select and the where conditions. 
    eg:
        'parameters': {
            'from_table': 'ocr',
            'select_column': 'highlight',
            'lookup_filters':[
                {
                    'column_name': 'Vendor GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
                {
                    'column_name': 'DRL GSTIN',
                    'compare_with':  {'source':'input', 'value':5}
                },
            ]
        }
    Note:
        1) Recursive evaluations of rules can be made for the parameter value.
        2) Its like vlook up in the dataframe and the from_table must have the primary key...case_id.
    """
    logging.info(f"parameters got are {parameters}")
    from_table = parameters['from_table']
    column_name_to_select = parameters['select_column']
    lookup_filters = parameters['lookup_filters']
    client_gstin = self.get_param_value(parameters['client_gstin'])

    # convert the from_table dictionary into pandas dataframe
    try:
        master_data = self.data_source[from_table]
    except Exception as e:
        logging.error(f"data source does not have the table {from_table}")
        logging.error(e)
        master_data = {}

    master_df = pd.DataFrame(master_data) 

    # build the query
    query = ""
    for lookup in lookup_filters:
        lookup_column = lookup['column_name']
        compare_value = self.get_param_value(lookup['compare_with'])
        query += f"{lookup_column} == '{compare_value}' & "
    query = query.strip(' & ') # the final strip for the extra &
    result_df = master_df.query(query)
    result_df = result_df.reset_index(drop=True)
    ###
    if not result_df.empty:
        client_id = result_df[column_name_to_select][0]
        ans = client_id
        print('old_case id is',ans)
        if client_id in ['CID0003', 'CID0004', 'CID0005', 'CID0006', 'CID0007', 'CID0008']:
            if len(client_gstin) > 2:
                state_code = client_gstin[:2]
                last_letter = client_gstin[-1]
                if str(state_code) == '07':
                    ans = 'CID0003'
                elif str(state_code) == '06':
                    ans = 'CID0004'
                elif str(state_code) == '29':
                    ans = 'CID0005'
                elif str(state_code) == '27':
                    ans = 'CID0006'
                elif str(last_letter) == 'W':
                    ans = 'CID0007'
                else:
                    ans = 'CID0008'
            print('new client_id is ',ans)
            return ans

    ###
    # get the wanted column from the dataframe
    if not result_df.empty:
        try:
            return result_df[column_name_to_select][0] # just return the first value of the matches
        except Exception as e:
            logging.error(f"error in selecting the required data from the result")
            logging.error(e)
            return ""

@register_method
def doTablesDeloitte(self, parameters):
    """ Works on inner tables present inside a column
    Args:
        parameters (dict): The source parameter which includes values that should be checked.
    eg:
        'parameters' :{
            'table_data':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'table_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'ocr_column':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'max_value':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
            'min_value':{'source':'input_config','table':'ocr','column':'Address_of_Vendor'},
        }
    """
    logging.info(f"parameters got are {parameters}")
    table_data = self.get_param_value(parameters['table_data'])
    table_column = self.get_param_value(parameters['table_column'])
    ocr_column = self.get_param_value(parameters['ocr_column'])
    max_value = self.get_param_value(parameters['max_value'])
    min_value = self.get_param_value(parameters['min_value'])
    try:
        table_data = json.loads(table_data)
    except:
        table_data = table_data

    logging.info(f"Table data got is : {table_data} and type is {type(table_data)}")
    Total_val = 0
    try:
        table_col = [values[0] for values in table_data[0]]
        logging.info(f"Got columns are: {table_col}")
        table_df = pd.DataFrame(columns = table_col)
        for ind in range(1,len(table_data)):
            row_ = [row_value[0] for row_value in table_data[ind]]
            logging.info(f"row is {row_}")
            table_df.loc[ind] = row_
        logging.info(f"Got the table is : {table_df}")
    except Exception as e:
        logging.error("Failed in converting table to data frame")
        logging.error(e)
        table_df = {}

    try:
        col_values = table_df[table_column].tolist()
        col_values.remove("")
        col_values.remove(" ")
    except Exception as e:
        logging.error(f"Removing of empty data in list failed")
        logging.error(e)

    try:
        for val in col_values:
            val = str(val).replace(",","")
            Total_val = Total_val+float(val)
    except Exception as e:
        logging.error("Addition of table failed")
        logging.error(e)
        Total_val = 0

    if ocr_column:
        ocr_column = ocr_column.replace(",","")
    else:
        ocr_column = 0

    logging.info(f"Got value after calculation is {Total_val - float(ocr_column)}")

    if float(min_value) < (Total_val - float(ocr_column)) < float(max_value):
        return True
    else:
        return False

@register_method
def doAuditUpdate(self, parameters):
    """Inserting data into Audit table.
    'parameters' :{
        'database_name' : {'source':'input','value':''},
        'table_name' : {'source':'input','value':''}
    }
    """
    logging.info(f"Got parameters in Audit Update function is : {parameters}")
    database_name = self.get_param_value(parameters['database_name'])
    table_name = self.get_param_value(parameters['table_name'])
    changed_data = {"state":"approved","queue":"approved"}
    stats_db = DB(database_name, tenant_id=self.tenant_id, **db_config)
    try:
        audit_insert_query = f"INSERT INTO `{table_name}` (`type`, `last_modified_by`, `table_name`, `reference_column`, `reference_value`, `changed_data`) VALUES (%s,%s,%s,%s,%s,%s)"
        params = ["update","checker","process_queue","case_id",self.case_id,json.dumps(changed_data,default=str)]
        stats_db.execute(audit_insert_query,params=params)
        logging.info(f"Successfully update table {table_name}")
        return True
    except Exception as e:
        logging.error(f"Inserting data into {table_name} got failed")
        logging.error(e)
        return False

@register_method
def doDateParser(self, parameters):
    """Accepts any type of input formate of date and returns required standard format

        'parameters' :{
            'input_date' : {'source':'input','value':''},
            'standard_format' : {'source':'input','value':''}
    }
    """
    logging.info(f"Parameters got in Date Parser function is {parameters}")
    standard_format = self.get_param_value(parameters['standard_format'])
    input_date = self.get_param_value(parameters['input_date'])

    try:
        parsed_date = parse(str(input_date), fuzzy=True, dayfirst=True).strftime(standard_format)
        logging.info(f"Date got after parsing is :{parsed_date}")
        return parsed_date
    except Exception as e:
        logging.error("DATE CONVERSION FAILED")
        logging.error(e)
        return input_date


@register_method
def doClientIDselect(self,parameters):
    logging.info(f"Parameters got in clientIDselect is {parameters}")
    client_name =  self.get_param_value(parameters['client_name'])
    client_gstin = self.get_param_value(parameters['client_gstin'])
    client_id = ''
    try:
        if client_gstin:
            two_digits = client_gstin[0:2]
            last_one = client_gstin[-1:]
            last_three = client_gstin[-3:-2]
            client_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            query_id = f"SELECT `client_id` from `client_master` where `client_name` like '%%{client_name}%%' AND left(gstin,2)='{two_digits}' AND right(gstin,1)='{last_one}' AND  left(right(gstin,3),1) ='{last_three}'"
            print(query_id)
            clieint_id_df = client_db.execute_(query_id)
            logging.info(f"filtered data is {type(clieint_id_df)}")
            if len(clieint_id_df) >= 1:
                client_id = clieint_id_df['client_id'][0]
            else:
                query_id = f"SELECT `client_id` from `client_master` where `client_name` like '%%{client_name}%%'"
                print(query_id)
                clieint_id_df = client_db.execute_(query_id)
                if len(clieint_id_df) >= 1:
                    client_id = clieint_id_df['client_id'][0]
                else:
                    client_id = ''
        else:
            client_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            query_id = f"SELECT `client_id` from `client_master` where `client_name` like '%%{client_name}%%'"
            print(query_id)
            clieint_id_df = client_db.execute_(query_id)
            client_id = clieint_id_df['client_id'][0]
        return client_id
    except Exception as e:
        logging.error(f"error in selecting client id")
        logging.error(e)
        return client_id

@register_method
def doVendorIDselect(self,parameters):
    logging.info(f"Parameters got in clientIDselect is {parameters}")
    vendor_name =  self.get_param_value(parameters['vendor_name'])
    vendor_gstin = self.get_param_value(parameters['vendor_gstin'])
    vendor_id = ''
    try:
        if vendor_gstin:
            two_digits = vendor_gstin[0:2]
            last_one = vendor_gstin[-1:]
            last_three = vendor_gstin[-3:-2]
            client_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            query_id = f"SELECT `vendor_id` from `vendor_master` where `vendor_name` like '%%{vendor_name}%%' AND left(gstin,2)='{two_digits}' AND right(gstin,1)='{last_one}' AND  left(right(gstin,3),1) ='{last_three}'"
            print(query_id)
            vendor_id_df = client_db.execute_(query_id)
            logging.info(f"filtered data is {type(vendor_id_df)}")
            if len(vendor_id_df) >= 1:
                vendor_id = vendor_id_df['vendor_id'][0]
            else:
                query_id = f"SELECT `vendor_id` from `vendor_master` where `vendor_name` like '%%{vendor_name}%%'"
                print(query_id)
                vendor_id_df = client_db.execute_(query_id)
                if len(vendor_id_df) >= 1:
                    vendor_id = vendor_id_df['vendor_id'][0]
                else:
                    vendor_id = ''
        else:
            client_db = DB('extraction', tenant_id=self.tenant_id, **db_config)
            query_id = f"SELECT `vendor_id` from `vendor_master` where `vendor_name` like '%%{vendor_name}%%'"
            print(query_id)
            vendor_id_df = client_db.execute_(query_id)
            vendor_id = vendor_id_df['vendor_id'][0]
        return vendor_id
    except Exception as e:
        logging.error(f"error in selecting vendor id")
        logging.error(e)
        return vendor_id

@register_method
def doAmountSyntax(self, parameters):
    """Returns the amounts with .00 and with commas of the parameter value."""
    logging.info(f"parameters got are {parameters}")
    output_amount = self.get_param_value(parameters['input_val'])
    print(len(str(output_amount)))
    if len(str(output_amount)) >= 1:
        print(len(str(output_amount)))
        try:
            output_amount2 = str(output_amount).replace(',','')
            output_amount=format_decimal(output_amount2, locale='en_IN')
            if '.' in output_amount:
                float_value = round(float(output_amount.replace(',','')),2)
                float_value = str(float_value)
                if float_value[-2] == '.':
                    print('here')
                    output_amount = output_amount.split('.')[0]+'.'+float_value[-1:]+'0'
                else:
                    output_amount = output_amount.split('.')[0]+'.'+float_value[-2:]
            else:
                output_amount = output_amount+'.00'
            return output_amount    
        except Exception as e:
            logging.error(e)
            return output_amount
    else:
        return output_amount

@register_method
def doSplitConcate(self, parameters):
    """Accepts any type of input formate of date and returns required standard format

        'parameters' :{
            'data' : {'source':'input','value':''},
            'split_index' : "",
            'value_to_concate': ""
    }
    """
    logging.info(f"Parameters got in Date Parser function is {parameters}")
    data = self.get_param_value(parameters['data'])
    split_index = parameters['split_index']
    value_to_concate = parameters['value_to_concate']
    data = str(data)
    if len(data) > 2:
        try:
            data_left = data[0:int(split_index)]
            logging.info(f"Got left split is : {data_left}")
            data_right = data[int(split_index):None]
            logging.info(f"Got right split is : {data_right}")
            concated_string = data_left + str(value_to_concate) + data_right
            logging.info(f"Got concated string is : {concated_string}")
            return concated_string
        except Exception as e:
            logging.error(f"Failed in spliting and converting data")
            logging.error(e)
            return data
    else:
        return data
